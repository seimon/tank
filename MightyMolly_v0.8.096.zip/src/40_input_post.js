// ---------------------------------------------------------------- 입력
const keys = new Set();
addEventListener('keydown', (e) => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  keys.add(e.code);
  if (UI.screen === pauseUI && e.code === 'KeyT' && !pauseUI.titleMode) { sfx.ui('button'); uiPress('title'); confirmUI.mode = 'title'; uiShow(confirmUI); }
  else if (UI.screen === pauseUI && pauseUI.tab === 3 && e.code === 'KeyR') { sfx.ui('button'); uiPress('reset'); confirmUI.mode = 'reset'; uiShow(confirmUI); }   // 설정: R = 모두 초기 값으로 (확인 창)   // 일시정지: T = 첫 화면으로 (확인 창)
  else if (UI.screen === pauseUI && pauseUI.tab === 3 && ['KeyW', 'KeyS', 'KeyA', 'KeyD'].includes(e.code)) pauseUI.setKey(e.code);   // '설정' 탭: W/S 항목, A/D 값
  else if (UI.screen === pauseUI && (e.code === 'KeyW' || e.code === 'KeyS') && !e.repeat) pauseUI.nudge(e.code === 'KeyW' ? -1 : 1);   // 강화 기록 넘겨 보기 (누르고 있으면 tick이 계속 넘긴다)
  else if (UI.screen === pauseUI && (e.code === 'KeyA' || e.code === 'KeyD')) pauseUI.toEnd(e.code === 'KeyD');   // 강화 기록 맨 위(A) / 맨 아래(D)
  else if (UI.screen === pauseUI && (e.code === 'KeyQ' || e.code === 'KeyE')) pauseUI.step(e.code === 'KeyE' ? 1 : -1);   // 탭: Q 왼쪽, E 오른쪽
  else if (UI.screen === confirmUI) { if (e.code === 'KeyY') { sfx.ui('button'); uiPress('yes'); confirmUI.yes(); } else if (e.code === 'KeyN') { sfx.ui('button'); uiPress('no'); uiShow(pauseUI); } }
  if (paused) return;
  if (e.code === 'KeyG' && titleState === 'play') {   // G: 적군 섬멸이면 새로 시작, 파괴됐으면 재출격, 아니면 세우기
    if (endState === 'clear') { sfx.ui('button'); uiPress('restart'); restartGame(false); }
    else if (endState === 'dead') { if (continuesLeft > 0) { sfx.ui('button'); uiPress('respawn'); } respawn(); }
    else if (!winUp()) uprightTank();   // 창이 떠 있으면 세우기도 안 됨
  }
  if (e.code === 'KeyC' && !e.repeat && titleState === 'play' && !winUp() && !editMode) { nextCamPreset(); sfx.ui('tab'); }   // C (패드 X): 카메라 모드 바꾸기
  if (e.code === 'KeyT' && (endState === 'clear' || endState === 'dead') && winUp()) { sfx.ui('button'); uiPress('title'); restartGame(true); }   // T: 첫 화면으로 (전투 불능·적군 섬멸 창)
});
// 뒤집혔을 때 세운다 (G키, 터치 '세우기' 버튼): 포탄 한 발을 쏜 것처럼 장전돼 있을 때만 되고, 하면 한 발 소모 (포탄은 안 나감)
function uprightTank() {
  if (!tank.solid || tank.cool > 0) return;
  tank.cool = tank.reload;
  _fwd.set(0, 0, 1).applyQuaternion(tank.q);
  if (inBoard(tank.pos.x, tank.pos.z, 2)) {
    const yaw = Math.atan2(_fwd.x, _fwd.z), o = openHopSpot(tank.pos.x, tank.pos.z);   // 주변이 트여 있으면 null → 제자리
    if (o) hopUpright(tank, o.x, o.z, yaw, true);   // 밀려나도 차체 방향은 그대로
    else hopUpright(tank, tank.pos.x, tank.pos.z, yaw);
    // 세우는 값: 남은 HP가 1이 되도록 (이미 1이면 대미지 없음). 대미지 숫자도
    const hp = Math.round(tank.hp);
    if (hp > 1 && !rulesLocked()) { tank.hp = 1; dmgTextHit(tank, hp - 1, null); hudHit(hp - 1); }
  } else spawnTank();
}
// 건물 사이에 낀 탱크가 G로 빠져나올 수 있게: 주변이 이미 트여 있으면 null(제자리에서 세운다), 막혀 있으면 가장 트인 쪽으로 (고른 자리까지의 절반만큼) 튀어올라 차체 방향 그대로 내려앉는다.
// 트임 = 그 자리에서 16방향 중 6m 넘게 막힘 없는 방향 수 (8방향 이상이면 트인 곳). 길이 열렸다 = 건물에서 1.6m 넘게 떨어져 탱크가 지나갈 수 있다
const OPEN_N = 16, OPEN_LEN = 6, OPEN_NEED = 8, PATH_M = 1.6;
function pathFree(x, z) {
  if (!inBoard(x, z, 3) || inFootprint(x, z, PATH_M) || cliffG[gridIndex(x, z)] > 0.3) return false;
  for (const p of allPoles) if (Math.hypot(p.x - x, p.z - z) < 1.8) return false;
  return true;   // (시냇물은 건너갈 수 있으니 막지 않는다)
}
function freeLen(x, z, a, max = 24) {   // 그 방향으로 막힘 없이 몇 m 가는가 (0.75m 간격)
  const sx = Math.sin(a), cz = Math.cos(a);
  for (let d = 0.75; d <= max; d += 0.75) if (!pathFree(x + sx * d, z + cz * d)) return d - 0.75;
  return max;
}
function openCount(x, z) {
  let n = 0;
  for (let i = 0; i < OPEN_N; i++) if (freeLen(x, z, i / OPEN_N * 6.2832, OPEN_LEN) >= OPEN_LEN) n++;
  return n;
}
function hopLandOK(x, z) {   // 떨어져 앉을 수 있는 자리 (landSpot과 같은 조건: 땅 위, 물길·다리·절벽·급경사·전봇대·다른 탱크와 떨어진 곳)
  if (!inBoard(x, z, 7) || creekD[gridIndex(x, z)] < CREEK_HW + 1 || bridgeDeckAt(x, z) > -1e8 || inFootprint(x, z, 2.6)) return false;
  if (allPoles.some((p) => Math.hypot(p.x - x, p.z - z) < 3.5)) return false;
  if (TANKS.some((T) => T !== tank && (T.solid || T.falling) && Math.hypot(T.pos.x - x, T.pos.z - z) < 6)) return false;
  let cliff = 0;
  for (const [a, b] of [[0, 0], [-2.5, -2.5], [2.5, -2.5], [-2.5, 2.5], [2.5, 2.5]]) cliff = Math.max(cliff, cliffG[gridIndex(x + a, z + b)]);
  if (cliff > 0.05) return false;
  const hs = [[-2.2, -2.2], [2.2, -2.2], [-2.2, 2.2], [2.2, 2.2]].map(([a, b]) => heightAt(x + a, z + b));
  return Math.max(...hs) - Math.min(...hs) <= 1.4;
}
function openHopSpot(x, z) {
  if (bridgeDeckAt(x, z) > -1e8) return null;   // 다리 위에서는 제자리
  const here = openCount(x, z);
  if (here >= OPEN_NEED) return null;
  let best = null;
  for (let i = 0; i < OPEN_N; i++) {
    const a = i / OPEN_N * 6.2832, len = freeLen(x, z, a);
    for (const d of [4.5, 6.5, 9, 12, 16, 20, 24]) {
      if (len < d) break;   // 그 방향 길이 열려 있는 만큼만 (건물 너머 안뜰로 넘어가지 않는다)
      const px = x + Math.sin(a) * d, pz = z + Math.cos(a) * d;
      if (!hopLandOK(px, pz)) continue;
      const score = openCount(px, pz) * 100 - d;   // 더 트인 곳, 같으면 가까운 곳 (트인 정도가 같으면 가장 가까운 자리)
      if (!best || score > best.score) best = { x: px, z: pz, yaw: a, dist: d, score, n: Math.round((score + d) / 100) };
    }
  }
  if (!best || best.n <= here) return null;   // 지금보다 더 트인 곳이 없으면 제자리
  // 밀리는 거리는 고른 자리까지의 절반. 그 자리에 앉을 수 없으면 조금씩 더 멀리 (끝은 고른 자리)
  for (const f of [0.5, 0.6, 0.7, 0.8, 0.9]) {
    const px = x + (best.x - x) * f, pz = z + (best.z - z) * f;
    if (hopLandOK(px, pz)) return { ...best, x: px, z: pz, dist: best.dist * f };
  }
  return best;
}
// 그 자리에서 resetLift(m)만큼 붕 떠올랐다가 떨어지며 자세를 잡는다. 올라가는 동안 바른 자세로 돌아가고, 착지는 낙하와 같은 처리
const _hq = new THREE.Quaternion(), _hp = new THREE.Vector3();
// move: 다른 자리로 넘어간다 → 그쪽으로 45도로 쏘아 올린 포물선 (수평으로 줄곧 나아가며 떠올랐다 내려앉는다)
function hopUpright(T, x, z, yaw, move = false) {
  _hq.copy(T.q); _hp.copy(T.pos);
  resetTank(x, z, yaw, T);   // 바른 자세와 착지 높이
  const g = 22, dh = T.pos.y - _hp.y, D = Math.hypot(T.pos.x - _hp.x, T.pos.z - _hp.z);
  T.hop = { q0: _hq.clone(), q1: T.q.clone(), p0: _hp.clone(), p1: T.pos.clone(), t: 0 };
  if (move && D > 0.5) {
    // 45도: 처음 위로 가는 속도 = 수평 속도 = v. D만큼 나아가 dh 높이에 닿는 v. 내려앉을 곳이 높아 45도로 못 닿으면 더 가파르게
    let vy, vh;
    if (D - dh > 0.6) vy = vh = Math.sqrt(g * D * D / (2 * (D - dh)));
    else { vy = Math.sqrt(2 * g * (Math.max(0, dh) + 1.5)); vh = D / ((vy + Math.sqrt(Math.max(0, vy * vy - 2 * g * dh))) / g); }
    const fly = D / vh;
    Object.assign(T.hop, { fly, vx: (T.pos.x - _hp.x) / fly, vz: (T.pos.z - _hp.z) / fly, vy0: vy, up: fly * 0.7 });   // 자세는 날아가는 시간의 70% 동안 바로잡는다
    T.vy = vy;
  } else {
    const lift = PC.resetLift ?? 4;
    T.hop.up = Math.sqrt(2 * g * (lift + Math.max(0, dh))) / g;
    T.vy = T.hop.up * g;
  }
  T.landY = T.pos.y; T.pos.copy(_hp); T.q.copy(_hq);
  T.falling = true; T.solid = false;
  landFx(T, true);   // 떠오르는 순간: 내려앉을 때와 같은 흙먼지·소리 (원래 있던 바닥에서)
  syncBody(T);
}
// 터치 조작: 아날로그 패드(위 = 전진, 좌우 = 선회)와 누르고 있는 동안 유지되는 버튼들. 마우스로도 된다
const touch = { thr: 0, steer: 0, up: false, down: false, fire: false, tl: false, tr: false };
// 게임패드 (81_ui.js padPoll이 매 프레임 채운다): 주행·선회·포탑·포각은 아날로그, fire = 발사 버튼을 누르고 있음
const pad = { thr: 0, steer: 0, tq: 0, de: 0, fire: false };
{
  const stick = $el('stick'), knob = $el('knob'), R = 50;
  let id = null;
  const move = (e) => {
    const r = stick.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy); if (d > R) { dx *= R / d; dy *= R / d; }
    knob.style.transform = `translate(${dx}px, ${dy}px)`;
    const dead = (v) => Math.abs(v) < 0.18 ? 0 : (v - Math.sign(v) * 0.18) / 0.82;   // 가운데 살짝은 무시
    touch.thr = dead(-dy / R); touch.steer = dead(-dx / R);
  };
  const end = () => { id = null; touch.thr = touch.steer = 0; knob.style.transform = ''; };
  const capture = (el, e) => { try { el.setPointerCapture(e.pointerId); } catch (_) {} };   // 손가락이 패드 밖으로 나가도 계속 따라가게
  stick.addEventListener('pointerdown', (e) => { id = e.pointerId; capture(stick, e); move(e); e.preventDefault(); });
  stick.addEventListener('pointermove', (e) => { if (e.pointerId === id) move(e); });
  stick.addEventListener('pointerup', end); stick.addEventListener('pointercancel', end);
  const hold = (btnId, key) => {
    const b = $el(btnId);
    const on = (v) => (e) => { touch[key] = v; b.classList.toggle('on', v); if (v) capture(b, e); e.preventDefault(); };
    b.addEventListener('pointerdown', on(true)); b.addEventListener('pointerup', on(false)); b.addEventListener('pointercancel', on(false));
  };
  hold('tUp', 'up'); hold('tDown', 'down'); hold('tFire', 'fire'); hold('tTL', 'tl'); hold('tTR', 'tr');
  $el('tFix').addEventListener('pointerdown', (e) => { uprightTank(); e.preventDefault(); });
  // 메뉴 토글. 처음엔 숨기고, 화면을 손가락으로 만지면 나타나고 키보드·게임패드를 쓰면 다시 숨긴다 (아이패드에 키보드를 연결해 할 때 계속 보이지 않게)
  const ui = $el('touchUI'), btn = $el('touchBtn');
  const show = (v) => { if ((ui.style.display !== 'none') === v) return; ui.style.display = v ? '' : 'none'; btn.textContent = v ? '터치 버튼 켜짐' : '터치 버튼 꺼짐'; };
  btn.onclick = (e) => { show(ui.style.display === 'none'); e.target.blur(); };
  show(false);
  addEventListener('pointerdown', (e) => { if (e.pointerType === 'touch') show(true); }, true);
  addEventListener('keydown', () => show(false), true);
}
addEventListener('keyup', (e) => keys.delete(e.code));
addEventListener('blur', () => keys.clear());

// ---------------------------------------------------------------- PS1 후처리: 저해상도 + 15비트 색 + 디더링
const rt = new THREE.WebGLRenderTarget(2, 2, {
  type: THREE.HalfFloatType, magFilter: THREE.NearestFilter, minFilter: THREE.NearestFilter,
});
rt.depthTexture = new THREE.DepthTexture(2, 2);   // 외곽선: 풀·땅에 가려진 가장자리는 긋지 않도록 화면 깊이와 비교
// 외곽선용 깊이: 레이어 1 물체만 색 없이 깊이로 (정점 떨림은 화면과 같게)
const olRT = new THREE.WebGLRenderTarget(2, 2, { magFilter: THREE.NearestFilter, minFilter: THREE.NearestFilter, depthTexture: new THREE.DepthTexture(2, 2) });
// 임무 완료: 내 탱크만 따로 그린 화면 (배경은 clear.background 단색). 후처리가 4x4 디더링으로 이쪽으로 바꿔 간다 (52_clear.js)
const cutRT = new THREE.WebGLRenderTarget(2, 2, { type: THREE.HalfFloatType, magFilter: THREE.NearestFilter, minFilter: THREE.NearestFilter });
cutRT.depthTexture = new THREE.DepthTexture(2, 2);
const olMat = ps1(new THREE.MeshBasicMaterial({ colorWrite: false }), null, 'outlineDepth');
// 외곽선 (config outline): 'off' / 'dof' = 아웃포커싱에 함께 흐려진다 (후처리를 두 번: 색·외곽선·림 → preRT → 아웃포커싱부터) / 'dither' = 흐린 곳에서 4x4 디더링으로 성긴다
const OLC = CFG.outline || {}, OL_MODES = ['off', 'dof', 'dither'], OL_NAME = { off: '외곽선 꺼짐', dof: '외곽선 켬 (아웃포커싱)', dither: '외곽선 켬 (흐린 곳 디더링)' };
let olMode = OL_MODES.includes(OLC.mode) ? OLC.mode : 'off', outlineOn = olMode !== 'off';
// 림 라이트 (config rimLight): 화면에서 정한 방향(시계)의 물체 가장자리를 주광 색으로 밝힌다. 외곽선과 같은 깊이(olRT)로
const RIM = Object.assign({ enabled: true, clock: 1.5, follow: 'moon', minFacing: 0.4, minUp: 0, width: 1, strength: 0.35, add: 0.04, fx: 1.2, fxRef: 300, fxAdd: 0.15, groundFade: [0.3, 1.2], groundDither: false }, CFG.rimLight);
let rimOn = !!RIM.enabled;
const preRT = new THREE.WebGLRenderTarget(2, 2, { type: THREE.HalfFloatType, magFilter: THREE.NearestFilter, minFilter: THREE.NearestFilter, depthBuffer: false });
const postScene = new THREE.Scene(), postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
// 가운데 창(전투 불능·적군 섬멸·일시정지·확인) 설정: 배경 회색조 두 색과 전환 시간, 창이 사라지는 시간, 창 색
const POPC = CFG.popup || {};
const POP = { dark: POPC.grayDark || '#191d20', light: POPC.grayLight || '#7b919b', grayTime: POPC.grayTime ?? 0.4, fade: POPC.fadeTime ?? 0.4,
  pause: POPC.pauseColor || '#cc8000', confirm: POPC.confirmColor || '#e0533c', dead: POPC.deadColor || '#e0533c', clear: POPC.clearColor || '#00b37d' };
const hexV3 = (h) => new THREE.Vector3(...[1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255));   // 색 그대로 (sRGB, 후처리도 sRGB에서 섞는다)
// 복셀 안개 (설정 메뉴 '복셀 안개', config voxelFog): 땅을 따라 height m 두께로 cell m 크기의 각진 안개 덩어리가 깔리고 천천히 흘러간다.
// 후처리에서 깊이로 화면 픽셀마다 보이는 자리를 되찾고, 거기서 카메라 쪽으로 march번 거슬러 올라가며 지나는 칸(복셀)마다 짙기를 쌓는다
// (칸 가운데에서 3D 노이즈 × 땅에서 높이 × 걷힘). 칸 안은 한 값이라 옆면까지 각진 덩어리로 보인다.
// 땅 높이는 지형 격자를 1m 텍스처(VF_TEX)로 한 번 굽는다.
// 걷힘은 '흉내 유체'(GPU, 128×128 = 보드 150m): 칸마다 걷힘(r)과 흐름 속도(g, b, m/s). 매 프레임 한 번 그려서
//   흐름을 따라 옮기고(semi-Lagrangian) → 잔잔한 소용돌이(curl 노이즈) → 바람 쪽으로 가라앉음 → 밀기(내 탱크·대포·폭발) → 천천히 다시 참.
//   압력 계산은 하지 않는다 (가볍게). 안개 무늬도 흐름만큼 살짝 밀려 보인다(flowWarp)
const VF = Object.assign({ enabled: false, height: 2.5, cell: 1.5, density: 1.0, scale: 0.09, speed: 0.35, color: '#94a0b0', steps: 4, march: 6,
  tankRadius: 3, blastRadius: 7, refill: 6, swirl: 1.5, damping: 1.2, windFollow: 0.3, cannonPush: 14, flowWarp: 0.4 }, CFG.voxelFog);
let vfOn = !!VF.enabled;
const VF_N = HALF * 2 + 1;   // 지형 격자 정사각을 1m 간격으로
// 땅 높이 텍스처·유체 격자는 처음 켤 때 만든다 (꺼져 있으면 아무것도 만들지 않고, 매 프레임 일도 하지 않는다)
let VF_TEX = null, vfFluid = null;
function hgtTex() {   // 땅 높이 1m 텍스처 (복셀 안개·림 라이트 바닥 쪽 옅게). 처음 쓸 때 한 번
  if (VF_TEX) return VF_TEX;
  const d = new Uint16Array(VF_N * VF_N);
  for (let z = 0; z < VF_N; z++) for (let x = 0; x < VF_N; x++) d[z * VF_N + x] = THREE.DataUtils.toHalfFloat(heightAt(x - HALF, z - HALF));
  VF_TEX = new THREE.DataTexture(d, VF_N, VF_N, THREE.RedFormat, THREE.HalfFloatType);
  VF_TEX.magFilter = VF_TEX.minFilter = THREE.LinearFilter; VF_TEX.needsUpdate = true;
  return VF_TEX;
}
function vfInit() {
  if (vfFluid) return;
  hgtTex();
  vfFluid = [0, 1].map(() => new THREE.WebGLRenderTarget(VF_FN, VF_FN, { type: THREE.HalfFloatType, magFilter: THREE.LinearFilter, minFilter: THREE.LinearFilter, depthBuffer: false }));
  postMat.uniforms.tHgt.value = VF_TEX; postMat.uniforms.tClr.value = vfFluid[0].texture;
}
const VF_FN = 128, VF_IMP = 8;
let vfCur = 0, vfT = 0;
const vfImps = [];   // 다음 한 번만 넣을 밀기: { x, z, r, push(바깥으로 m/s), dx, dz(그 방향으로 m/s), clear(0~1) }
const vfFluidMat = new THREE.ShaderMaterial({
  uniforms: { tPrev: { value: null }, uDt: { value: 0 }, uT: { value: 0 }, uSwirl: { value: VF.swirl }, uDamp: { value: VF.damping }, uRefill: { value: VF.refill },
    uWind: { value: new THREE.Vector2() }, uImp: { value: Array.from({ length: VF_IMP }, () => new THREE.Vector4()) }, uImpD: { value: Array.from({ length: VF_IMP }, () => new THREE.Vector4()) } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: `
    uniform sampler2D tPrev; uniform float uDt, uT, uSwirl, uDamp, uRefill; uniform vec2 uWind; uniform vec4 uImp[${VF_IMP}], uImpD[${VF_IMP}]; varying vec2 vUv;
    float h2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
    float n2(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(h2(i), h2(i + vec2(1, 0)), f.x), mix(h2(i + vec2(0, 1)), h2(i + vec2(1, 1)), f.x), f.y); }
    vec2 curl(vec2 p) { const float e = 0.5; return vec2(n2(p + vec2(0, e)) - n2(p - vec2(0, e)), n2(p - vec2(e, 0)) - n2(p + vec2(e, 0))) / (2.0 * e); }
    void main() {
      vec4 s = texture2D(tPrev, vUv - texture2D(tPrev, vUv).gb * uDt / ${(HALF * 2).toFixed(1)});   // 흐름을 따라 거슬러 가서 가져온다
      float c = s.r; vec2 v = s.gb, w = vUv * ${(HALF * 2).toFixed(1)} - ${HALF.toFixed(1)};   // w = 월드 xz
      v += curl(w * 0.12 + uT * 0.15) * uSwirl * uDt;   // 잔잔한 소용돌이
      v = uWind + (v - uWind) * exp(-uDamp * uDt);   // 바람 쪽으로 가라앉는다
      for (int i = 0; i < ${VF_IMP}; i++) {   // 밀기
        vec4 I = uImp[i]; if (I.z <= 0.0) continue;
        vec2 d = w - I.xy; float r = length(d), k = 1.0 - smoothstep(0.0, I.z, r);
        if (k <= 0.0) continue;
        vec4 D = uImpD[i];
        v += ((r > 0.01 ? d / r : vec2(0.0)) * I.w + D.xy) * k;
        c = max(c, D.z * k);
      }
      c = max(0.0, c - uDt / uRefill);   // 다시 찬다
      gl_FragColor = vec4(c, clamp(v, -25.0, 25.0), 1.0);
    }`,
  depthTest: false, depthWrite: false,
});
const vfFluidScene = new THREE.Scene(), vfFluidCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
vfFluidScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), vfFluidMat));
// 한 번 밀기 (대포·폭발): push = 바깥으로, (dx, dz) = 그 방향으로 (m/s), clear = 가운데를 걷는 정도
function vfPush(x, z, r, push, dx = 0, dz = 0, clear = 0) { if (vfOn && vfImps.length < VF_IMP - 1) vfImps.push({ x, z, r, push, dx, dz, clear }); }
function vfStamp(x, z, r) { vfPush(x, z, r, 16 * r / Math.max(1, VF.blastRadius), 0, 0, 0.9); }   // 폭발
// 유체 한 걸음 (게임이 멈추면 안 부른다). 내 탱크는 매 프레임 밀고, 한 번짜리 밀기는 이번에 넣고 비운다
function vfStep(dt) {
  if (!vfOn || !vfFluid || dt <= 0) return;
  vfT += dt;
  const u = vfFluidMat.uniforms, list = [];
  if (tank && tank.pos) { const sp = Math.hypot(tank.vel.x, tank.vel.z); list.push({ x: tank.pos.x, z: tank.pos.z, r: VF.tankRadius, push: (0.3 + sp * 0.5) * dt * 3, dx: tank.vel.x * dt * 2, dz: tank.vel.z * dt * 2, clear: 1 }   /* 서 있으면 거의 안 민다 (구멍만), 달릴수록 옆·앞으로 */); }
  list.push(...vfImps.splice(0));
  for (let i = 0; i < VF_IMP; i++) {
    const m = list[i];
    if (m) { u.uImp.value[i].set(m.x, m.z, m.r, m.push); u.uImpD.value[i].set(m.dx, m.dz, m.clear, 0); } else u.uImp.value[i].set(0, 0, 0, 0);
  }
  const wd = U.uWindDir.value, ws = U.uWind.value * VF.windFollow;
  u.uWind.value.set(wd.x * ws, wd.y * ws); u.uDt.value = Math.min(dt, 0.05); u.uT.value = vfT;
  const prev = vfFluid[vfCur], next = vfFluid[vfCur ^ 1];
  u.tPrev.value = prev.texture;
  renderer.setRenderTarget(next); renderer.render(vfFluidScene, vfFluidCam); renderer.setRenderTarget(null);
  vfCur ^= 1;
  postMat.uniforms.tClr.value = next.texture;
}
function vfReset() {   // 안개를 끄면 유체를 비운다 (지우는 색은 원래대로 돌려 둔다)
  if (!vfFluid) return;
  const c = renderer.getClearColor(new THREE.Color()), al = renderer.getClearAlpha();
  renderer.setClearColor(0x000000, 0);
  for (const t of vfFluid) { renderer.setRenderTarget(t); renderer.clear(); }
  renderer.setRenderTarget(null); renderer.setClearColor(c, al);
}
const _vfM = new THREE.Matrix4();
// 카메라 모드 (config camera 안에서 name이 있는 묶음마다 하나: default 기본, miniature 미니어처 …. 묶음을 더하면 설정 탭·C키에 그대로 나온다).
// 모드마다: fov·distance·minDistance·maxDistance·pitch·yaw·lead·follow·height(화면 가운데를 탱크보다 위로)·fog(맵 안개 짙기 배율)·moon(맵 주광 세기 배율)·drag(끌어 돌리기)·dof(아웃포커싱).
// 바꾸면 camera.switchTime초에 걸쳐 EaseInOutCubic으로 넘어간다: CAMV = 지금 섞인 값 (camPreTick이 매 프레임 맞춘다). 게임을 시작할 때는 늘 camera.start.
// 아웃포커싱: 초점(카메라 → 내 탱크 거리)에서 range m 밖으로 멀어질수록(앞·뒤 모두) 주변을 섞어 흐리게 (15비트 색·디더링 전).
// 값은 화면마다의 카메라에서: 타이틀 = title.camera.dof, 플레이 = 카메라 모드 dof, 임무 완료 = clear.camera.dof (titleK·clearSeq.k로 섞는다)
const IS_MOBILE = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 1 && /Mac|iPad|iPhone|Android/.test(navigator.userAgent);
const CAM_BASE = { fov: 45, distance: 42, minDistance: 8, maxDistance: 70, pitch: 28, yaw: 20, lead: 9, follow: 1.8, height: 0, fog: 1, moon: 1 };
const DOF_BASE = { strength: 1, range: 4, fall: 30, px: 2.6 }, DOF_KEYS = ['strength', 'range', 'fall', 'px'];
const dofOf = (d, s0) => Object.assign({}, DOF_BASE, { strength: s0 }, d);   // (빠진 값 채우기. s0 = 세기 기본값)
const TITLE_DOF = dofOf(CFG.title?.camera?.dof, 0);
if (CFG.title) (CFG.title.camera = CFG.title.camera || {}).dof = TITLE_DOF;
const CAMP_KEYS = (() => {
  const C = CFG.camera = CFG.camera || {};
  let L = Object.keys(C).filter((k) => C[k] && typeof C[k] === 'object' && !Array.isArray(C[k]) && C[k].name);
  if (!L.length) { C.default = { name: '기본' }; L = ['default']; }   // 예전 형식 (camera에 값이 바로 있음): 그 값으로 모드 하나
  for (const k of L) {
    const m = C[k];
    for (const a in CAM_BASE) if (m[a] === undefined) m[a] = C[a] ?? CAM_BASE[a];
    m.dof = dofOf(m.dof, 1);
  }
  return L;
})();
const CAMP_CFG0 = JSON.stringify(CAMP_KEYS.map((k) => CFG.camera[k]));   // 처음 값 (설정 메뉴 카메라 [초기화])
const CAMP_START = CAMP_KEYS.includes(CFG.camera.start) ? CFG.camera.start : CAMP_KEYS[0];
let camPre = CAMP_START;   // (기억하지 않는다: 시작할 때마다 start)
const camPreCfg = () => CFG.camera[camPre];
const CAMV = { dof: {} };   // 지금 섞인 카메라 값
let camTr = null;   // 넘어가는 중: { from: 그때의 CAMV, t, T }
const _camEase = (t) => t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
function camValues() {
  const to = camPreCfg(), f = camTr && camTr.from, e = f ? _camEase(Math.min(1, camTr.t / camTr.T)) : 1;
  for (const a in CAM_BASE) CAMV[a] = f ? lerp(f[a], to[a], e) : to[a];
  for (const a of DOF_KEYS) CAMV.dof[a] = f ? lerp(f.dof[a], to.dof[a], e) : to.dof[a];
}
camValues();
function camLimits() {   // 끌기·휠을 OrbitControls가 맡을지 (거리 범위는 camRange가 매 프레임)
  const m = camPreCfg();
  const A = camDragAxes(); controls.enableRotate = A.h.m === 'free' && A.v.m === 'free';   // 한쪽이라도 러버밴딩·꺼짐이면 OrbitControls로는 돌리지 않는다 (camElastic)
  controls.enableZoom = m.zoom !== 'spring';   // 휠 스프링이면 camElastic이 직접
}
camLimits();
camera.fov = CAMV.fov; camera.updateProjectionMatrix();
function setCamPreset(k) {
  if (!CAMP_KEYS.includes(k) || k === camPre) return;
  camTr = { from: { ...CAMV, dof: { ...CAMV.dof } }, t: 0, T: Math.max(0.01, CFG.camera.switchTime ?? 1) };
  camPre = k;
  camLimits(); camElReset();
  if (titleK >= 1 && !clearSeq) camRetBegin(camTr.T);   // 플레이: 카메라 자리도 같은 시간에 새 거리·각도로 (자동 카메라를 꺼도)
}
function nextCamPreset() {   // C키 / 패드 X: 다음 모드로, 좌하단에 알림 (82_dmgtext.js)
  setCamPreset(CAMP_KEYS[(CAMP_KEYS.indexOf(camPre) + 1) % CAMP_KEYS.length]);
  showCamToast(`카메라 모드: ${camPreCfg().name}`);
}
let _camFog = CAMV.fog, _camMoon = CAMV.moon, _camYaw = CAMV.yaw;
// 마우스 휠 거리 범위: 플레이 중에만 모드의 min·maxDistance (OrbitControls는 update마다 거리를 이 범위로 자르므로, 타이틀·임무 완료·편집 모드·모드를 바꾸는 중에는 풀어 둔다.
// 안 그러면 미니어처의 90m 아래로 못 가서 임무 완료 카메라(20m)가 멀리 밀려난다)
function camRange() {
  const m = camPreCfg(), play = !camTr && titleK >= 1 && !clearSeq && !editMode && !decalMode;
  controls.minDistance = play ? Math.min(m.minDistance, m.distance) : 0.5;
  controls.maxDistance = play ? Math.max(m.maxDistance, m.distance) : 1e4;
}
function camPreTick(dt) {   // 매 프레임 (카메라 맞추기 전)
  if (camTr && (camTr.t += dt) >= camTr.T) { camTr = null; camLimits(); }
  camValues(); camRange();
  if (CAMV.yaw !== _camYaw) { if (titleK >= 1 && !clearSeq) camYaw += (CAMV.yaw - _camYaw) * DEG; _camYaw = CAMV.yaw; }   // 모드의 yaw가 바뀐 만큼은 follow를 기다리지 않고 바로 (넘어가는 시간 그대로)
  if (CAMV.fog !== _camFog || CAMV.moon !== _camMoon) { _camFog = CAMV.fog; _camMoon = CAMV.moon; applyEnv(); }   // 안개 짙기·주광 세기 (넘어가는 동안만)
  if (titleK >= 1 && !clearSeq && camera.fov !== CAMV.fov) { camera.fov = CAMV.fov; camera.updateProjectionMatrix(); U.uPointScale.value = lowH / (2 * Math.tan(CAMV.fov * DEG / 2)); }
}
const postMat = new THREE.ShaderMaterial({
  uniforms: { tDrop: { value: LDROP_TEX }, uDrop: { value: 0 }, uDropR: { value: 0.035 * (LD.refract ?? 1) }, tDiffuse: { value: rt.texture }, tCut: { value: cutRT.texture }, tCutD: { value: cutRT.depthTexture }, uCut: { value: 0 }, uFlash: { value: 0 }, tDepth: { value: rt.depthTexture }, tOL: { value: olRT.depthTexture },
    uOL: { value: 0 }, uOLDith: { value: 0 }, uOLCol: { value: OLC.color ?? 1 }, uOLDark: { value: OLC.dark ?? 0.3 }, uOLSat: { value: OLC.saturate ?? 1.5 }, tPre: { value: preRT.texture },
    uRim: { value: 0 }, uRimW: { value: 1 }, uRimDir: { value: new THREE.Vector2(1, 1) }, uRimC: { value: new THREE.Vector3() }, uRimA: { value: new THREE.Vector3() },
    uView: { value: new THREE.Matrix4() }, uFxP: { value: [0, 1, 2, 3].map(() => new THREE.Vector3()) }, uFxC: { value: [0, 1, 2, 3].map(() => new THREE.Vector3()) }, uFxR: { value: [0, 0, 0, 0] },
    uRimFxA: { value: RIM.fxAdd ?? 0.15 }, uRimMin: { value: RIM.minFacing ?? 0.4 }, uRimG0: { value: RIM.groundFade?.[0] ?? 0.3 }, uRimG1: { value: RIM.groundFade?.[1] ?? 1.2 }, uRimGD: { value: RIM.groundDither ? 1 : 0 },
    uNear: { value: camera.near }, uFar: { value: camera.far }, uTexel: { value: new THREE.Vector2(1, 1) },
    uFogN: FOGN, uFogF: FOGF, uFogC: { value: FOG }, uDof: { value: 0 }, uFocus: { value: 20 }, uFocusR: { value: CAMV.dof.range }, uFocusF: { value: CAMV.dof.fall }, uDofPx: { value: CAMV.dof.px },
    uGrad: { value: 0 }, uGradA: { value: 0.6 }, uGradB: { value: 0.9 }, uGradC: { value: new THREE.Color(1, 1, 1) },
    uGray: { value: 0 }, uGrayA: { value: hexV3(POP.dark) }, uGrayB: { value: hexV3(POP.light) }, uBright: { value: 1 },
    tHgt: { value: null }, tClr: { value: null }, uVFWarp: { value: VF.flowWarp }, uCamP: { value: new THREE.Vector3() }, uVFMarch: { value: VF.march }, uInvPV: { value: new THREE.Matrix4() }, uVF: { value: 0 }, uVFTop: { value: VF.height }, uVFCell: { value: VF.cell }, uVFDen: { value: VF.density },
    uVFScale: { value: VF.scale }, uVFT: { value: 0 }, uVFSteps: { value: VF.steps }, uVFC: { value: new THREE.Color(VF.color) } },
  defines: { STAGE: 0 },   // 0 = 한 번에 다, 1 = 색·빗방울·외곽선·림까지 (preRT), 2 = preRT에서 아웃포커싱부터 (외곽선 'dof' 모드)
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: `
    uniform sampler2D tPre; uniform float uOLDith, uOLCol, uOLDark, uOLSat, uRim, uRimW; uniform vec2 uRimDir; uniform vec3 uRimC, uRimA;
    uniform mat4 uView; uniform vec3 uFxP[4], uFxC[4]; uniform float uFxR[4], uRimFxA, uRimMin, uRimG0, uRimG1, uRimGD;
    uniform sampler2D tHgt, tClr; uniform vec3 uCamP; uniform float uVFMarch, uVFWarp; uniform mat4 uInvPV; uniform float uVF, uVFTop, uVFCell, uVFDen, uVFScale, uVFT, uVFSteps; uniform vec3 uVFC;
    uniform float uDof, uFocus, uFocusR, uFocusF, uDofPx;
    uniform sampler2D tDiffuse, tDepth, tOL, tCut, tCutD, tDrop; uniform float uCut, uDrop, uDropR, uFlash, uOL, uNear, uFar, uFogN, uFogF, uGrad, uGradA, uGradB, uGray, uBright; uniform vec2 uTexel; uniform vec3 uFogC, uGradC, uGrayA, uGrayB; varying vec2 vUv;
    float lin(float d) { return uNear * uFar / (uFar - d * (uFar - uNear)); }   // 깊이 버퍼 값 → 카메라에서 거리
    float bayer2(vec2 a) { a = floor(a); return fract(dot(a, vec2(0.5, a.y * 0.75))); }
    float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }
    float vfH(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
    float vfNoise(vec3 p) {   // 3D 값 노이즈 (0~1)
      vec3 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
      return mix(mix(mix(vfH(i), vfH(i + vec3(1, 0, 0)), f.x), mix(vfH(i + vec3(0, 1, 0)), vfH(i + vec3(1, 1, 0)), f.x), f.y),
                 mix(mix(vfH(i + vec3(0, 0, 1)), vfH(i + vec3(1, 0, 1)), f.x), mix(vfH(i + vec3(0, 1, 1)), vfH(i + vec3(1, 1, 1)), f.x), f.y), f.z);
    }
    // 임무 완료: 지운 픽셀(cut)은 탱크만 그린 화면에서 (외곽선도 그 깊이로)
    float olD(vec2 uv, bool cut) { return cut ? texture2D(tCutD, uv).r : texture2D(tOL, uv).r; }
    float scD(vec2 uv, bool cut) { return cut ? texture2D(tCutD, uv).r : texture2D(tDepth, uv).r; }
    vec3 toSRGB(vec3 c) { c = max(c, 0.0); return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
    vec3 colAt(vec2 uv, bool cut) {
    #if STAGE == 2
      return texture2D(tPre, uv).rgb;   // 색·외곽선·림까지 그린 것 (1단계)
    #else
      return cut ? texture2D(tCut, uv).rgb : texture2D(tDiffuse, uv).rgb;
    #endif
    }
    // 외곽선·림 라이트 (keep: 0~1 = 그리는 정도, 'dither' 모드면 흐린 곳에서 디더링으로 0). oc = 그 픽셀의 원래 물체 색
    // 림: dir 쪽으로 uRimW칸 안에 훨씬 먼 곳(물체만 그린 깊이)이 있으면 켠다. 단 화면 깊이로 그 자리가 이 물체보다 앞이면(풀·땅이 앞을 가림) 빼고
    // 가로·세로를 따로 보고 dir 성분 비율로 섞는다 (한 방향을 픽셀로 반올림하면 빛이 눕는 순간 수평 가장자리 림이 탁 꺼졌다)
    bool rimHit(vec2 q, float d, float gap, bool cut) { return lin(olD(q, cut)) - d > gap && lin(scD(q, cut)) - d > 0.3; }
    float rimAt(vec2 dir, float d, float gap, bool cut) {
      vec2 sx = vec2(dir.x >= 0.0 ? uTexel.x : -uTexel.x, 0.0), sy = vec2(0.0, dir.y >= 0.0 ? uTexel.y : -uTexel.y);
      float rx = 0.0, ry = 0.0;
      for (int k = 1; k <= 6; k++) {
        if (float(k) > uRimW) break;
        if (rx < 0.5 && rimHit(vUv + sx * float(k), d, gap, cut)) rx = 1.0;
        if (ry < 0.5 && rimHit(vUv + sy * float(k), d, gap, cut)) ry = 1.0;
      }
      return min(1.0, rx * abs(dir.x) + ry * abs(dir.y));
    }
    vec2 rimDir(vec2 v) { return v / max(max(abs(v.x), abs(v.y)), 1e-4); }
    void edges(inout vec3 lc, vec3 oc, bool cut, float keep) {
      float d0 = olD(vUv, cut);
      if (d0 >= 1.0 || keep <= 0.0) return;
      float d = lin(d0);
      if (lin(scD(vUv, cut)) < d - 0.3 - d * 0.02) return;   // 풀·땅에 가려진 곳은 빼고
      float fk = max(d - uFogN, 0.0) * 2.0 / max(uFogF - uFogN, 0.001), fogK = 1.0 - exp(-fk * fk);   // 지형과 같은 안개: 멀수록 묻힌다
      float gap = 0.6 + d * 0.06;
      if (uRim > 0.5) {   // 림: 빛 쪽 가장자리를 밝힌다 (외곽선이 켜져 있으면 uRimW가 한 칸 더 = 선 바로 안쪽). 주광 + 주변 광원 4개
        vec4 wp = uInvPV * vec4(vUv * 2.0 - 1.0, d0 * 2.0 - 1.0, 1.0); vec3 P = wp.xyz / wp.w;   // 이 픽셀의 월드 자리
        float gk = smoothstep(uRimG0, uRimG1, P.y - texture2D(tHgt, (P.xz + ${HALF.toFixed(1)}) / ${VF_N.toFixed(1)} + 0.5 / ${VF_N.toFixed(1)}).r);   // 땅에 가까울수록 옅게
        if (uRimGD > 0.5) gk = step(bayer4(gl_FragCoord.xy), gk - 0.01);   // (디더링으로)
        gk *= (1.0 - fogK) * keep;
        if (gk > 0.0) {
          vec3 add = (oc * uRimC + uRimA) * rimAt(uRimDir, d, gap, cut);
          for (int i = 0; i < 4; i++) {   // 폭발·섬광·불빛: 이 자리에서 광원 쪽을 화면에 비춘 방향
            if (uFxR[i] <= 0.0) continue;
            vec3 L = uFxP[i] - P; float ld = length(L);
            if (ld >= uFxR[i]) continue;
            vec3 v = mat3(uView) * L; float a = 1.0 - ld / uFxR[i];
            add += (oc + uRimFxA) * uFxC[i] * (a * a * max(length(v.xy) / max(ld, 1e-3), uRimMin)) * rimAt(rimDir(v.xy), d, gap, cut);
          }
          lc += add * gk;
        }
      }
      if (uOL > 0.5) {   // 외곽선: 물체 픽셀인데 이웃 중 훨씬 먼 곳(배경·뒤의 물체)이 있으면 1픽셀 선. 색은 물체 색을 어둡게 (uOLCol 0 = 예전 검정)
        float m = max(max(lin(olD(vUv + vec2(uTexel.x, 0.0), cut)), lin(olD(vUv - vec2(uTexel.x, 0.0), cut))),
                      max(lin(olD(vUv + vec2(0.0, uTexel.y), cut)), lin(olD(vUv - vec2(0.0, uTexel.y), cut))));
        if (m - d > gap) {
          vec3 lum = vec3(dot(oc, vec3(0.2126, 0.7152, 0.0722)));
          vec3 lineC = mix(vec3(0.012, 0.01, 0.008), max(mix(lum, oc, uOLSat), 0.0) * uOLDark, uOLCol);
          lc = mix(lc, mix(lineC, uFogC, fogK), 0.9 * keep);
        }
      }
    }
    void main() {
      bool cut = uCut > 0.0 && bayer4(gl_FragCoord.xy) < clamp(uCut * 2.0 - vUv.y, 0.0, 1.0);   // 화면 아래에서 위로 쓸어 올리며
      vec2 uvR = vUv; float dA = 0.0;
    #if STAGE != 2
      if (uDrop > 0.0) { vec4 dr = texture2D(tDrop, vUv); dA = dr.a; uvR = clamp(vUv + (dr.rg - 0.5) * 2.0 * uDropR * dA, 0.0, 1.0); }   // 화면에 맺힌 빗방울: 그만큼 어긋나게 읽는다 (22_weather.js)
    #endif
      vec3 lc = colAt(uvR, cut), oc = lc;
    #if STAGE == 1
      if (dA > 0.0) { float b = texture2D(tDrop, vUv).b, db = (b - 0.5) * 2.0; lc = b > 0.99 ? mix(lc, vec3(0.75), dA) : lc * (1.0 + db * 0.6 * dA) + max(db - 0.2, 0.0) * 0.1 * dA; }
      edges(lc, oc, cut, 1.0);
      gl_FragColor = vec4(lc, 1.0);
    #else
      float coc = 0.0;
      if (uDof > 0.0) {   // 아웃포커싱: 초점에서 먼 만큼(coc) 둘레 8곳을 섞는다. 흐린 이웃일수록 많이 (또렷한 물체가 흐린 배경으로 번지지 않게)
        coc = clamp((abs(lin(scD(uvR, cut)) - uFocus) - uFocusR) / uFocusF, 0.0, 1.0) * uDof;
        if (coc > 0.02) {
          vec3 acc = lc; float ws = 1.0;
          for (int i = 0; i < 8; i++) {
            float a = float(i) * 0.785398 + 0.39;
            vec2 q = clamp(uvR + vec2(cos(a), sin(a)) * uTexel * uDofPx * coc * (i % 2 == 0 ? 1.0 : 0.55), 0.0, 1.0);
            float w = 0.2 + clamp((abs(lin(scD(q, cut)) - uFocus) - uFocusR) / uFocusF, 0.0, 1.0);
            acc += colAt(q, cut) * w; ws += w;
          }
          lc = acc / ws;
        }
      }
    #if STAGE == 0
      if (dA > 0.0) { float b = texture2D(tDrop, vUv).b, db = (b - 0.5) * 2.0; lc = b > 0.99 ? mix(lc, vec3(0.75), dA) : lc * (1.0 + db * 0.6 * dA) + max(db - 0.2, 0.0) * 0.1 * dA; }   // 방울 밝기 (b): 둘레 어둡게, 초승달 밝게, 1 = 반짝 점(단색)
      edges(lc, oc, cut, uOLDith > 0.5 && coc > 0.02 ? step(coc, bayer4(gl_FragCoord.xy) + 0.03) : 1.0);   // 'dither': 흐린 만큼 성기게
    #endif
      if (uVF > 0.0) {   // 복셀 안개: 보이는 자리에서 카메라 쪽으로 거슬러 올라가며 지나는 칸마다 짙기를 쌓는다
        float d = texture2D(tDepth, vUv).r;
        vec4 w = uInvPV * vec4(vUv * 2.0 - 1.0, (d < 1.0 ? d : 0.9999) * 2.0 - 1.0, 1.0);
        vec3 P = w.xyz / w.w, dir = normalize(uCamP - P);
        float len = min(distance(uCamP, P), uVFTop * 2.5 / max(dir.y, 0.25)), st = len / uVFMarch, tr = 1.0;   // 안개 층을 지나는 만큼만
        for (int i = 0; i < 12; i++) {
          if (float(i) >= uVFMarch) break;
          vec3 q = (floor((P + dir * (st * (float(i) + 0.5))) / uVFCell) + 0.5) * uVFCell;   // 칸 가운데
          vec2 tu = (q.xz + ${HALF.toFixed(1)}) / ${VF_N.toFixed(1)} + 0.5 / ${VF_N.toFixed(1)};
          float hy = q.y - texture2D(tHgt, tu).r;   // 땅에서 높이
          if (hy > uVFTop || hy < -uVFCell) continue;
          vec3 fl = texture2D(tClr, ${UVW('q.xz')}).rgb;   // 흉내 유체: r = 걷힘, gb = 흐름 (m/s)
          vec2 qw = q.xz - fl.gb * uVFWarp;   // 흐름만큼 무늬가 밀려 보인다
          float n = vfNoise(vec3(qw.x * uVFScale + uVFT, qw.y * uVFScale + uVFT * 0.6, q.y * uVFScale * 2.0 + uVFT * 0.25));
          float den = smoothstep(0.4, 0.7, n) * (1.0 - smoothstep(uVFTop * 0.4, uVFTop, hy)) * (1.0 - fl.r);
          tr *= exp(-den * uVFDen * st * 0.9);
        }
        float a = (1.0 - tr) * uVF;
        a = clamp(floor(a * uVFSteps + bayer4(gl_FragCoord.xy)) / uVFSteps, 0.0, 1.0);   // uVFSteps단계 + 4x4 디더
        lc = mix(lc, uVFC, a);
      }
      lc = mix(lc, uGradC, uGrad * smoothstep(uGradA, uGradB, vUv.y));   // 타이틀: 화면 위쪽으로 갈수록 흰색 (아래 → 위, 0~1)
      vec3 c = toSRGB(lc);
      c = pow(c, vec3(1.0 / uBright));   // 화면 밝기 (설정)
      c = mix(c, vec3(1.0, 0.94, 0.82), uFlash * 0.7);
      if (uGray > 0.0) c = mix(c, mix(uGrayA, uGrayB, dot(c, vec3(0.299, 0.587, 0.114))), uGray);   // 끝 창·일시정지: 밝기를 두 색 사이로 (그라디언트 맵)
      c = floor(c * 31.0 + 0.5 + (bayer4(gl_FragCoord.xy) - 0.5)) / 31.0;
      gl_FragColor = vec4(c, 1.0);
    #endif
    }`,
});
// 외곽선 'dof' 모드의 두 단계 (uniform은 postMat과 같은 묶음을 함께 쓴다)
const postMatOf = (stage) => new THREE.ShaderMaterial({ uniforms: postMat.uniforms, defines: { STAGE: stage }, vertexShader: postMat.vertexShader, fragmentShader: postMat.fragmentShader });
const preMat = postMatOf(1), post2Mat = postMatOf(2);
const postMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), postMat);
postScene.add(postMesh);
postMat.uniforms.uVFC.value.convertSRGBToLinear();   // 장면 색(선형)에 섞는다
// 후처리 그리기 (rt → postRT). 외곽선 'dof' 모드이고 아웃포커싱이 걸려 있으면 두 번: 색·외곽선·림 → preRT, 그다음 아웃포커싱부터
function renderPost() {
  postUniforms();
  const u = postMat.uniforms, two = olMode === 'dof' && (u.uOL.value > 0 || u.uRim.value > 0) && u.uDof.value > 0;
  if (two) { postMesh.material = preMat; renderer.setRenderTarget(preRT); renderer.render(postScene, postCam); }
  postMesh.material = two ? post2Mat : postMat;
  renderer.setRenderTarget(postRT); renderer.render(postScene, postCam);
}
function setOutlineMode(m, init) {
  olMode = OL_MODES.includes(m) ? m : 'off'; outlineOn = olMode !== 'off';
  const u = postMat.uniforms; u.uOL.value = outlineOn ? 1 : 0; u.uOLDith.value = olMode === 'dither' ? 1 : 0;
  const b = $el('olBtn'); if (b) b.textContent = OL_NAME[olMode];
  if (!init) { pausedDrawn = false; pauseScene = false; }   // (처음 부를 때는 90_loop.js의 이름이 아직 없다)
}
// 카툰 명암 (config toon): 셰이더는 그대로, uniform 값만 (00_core.js ps1)
const TOON = Object.assign({ enabled: false, strength: 1, ground: 0, steps: 2, soft: 0.02, dark: 0 }, CFG.toon);
let toonOn = !!TOON.enabled;
function setToon(v) {
  toonOn = !!v;
  U.uToon.value = toonOn ? TOON.strength : 0; U.uToonG.value = toonOn ? TOON.ground : 0;
  U.uToonN.value = Math.min(6, Math.max(1, Math.round(TOON.steps))); U.uToonS.value = Math.max(1e-4, TOON.soft); U.uToonD.value = TOON.dark;
  const b = $el('toonBtn'); if (b) b.textContent = toonOn ? '카툰 명암 켜짐' : '카툰 명암 꺼짐';
}
function setRim(v, init) {
  rimOn = !!v;
  const b = $el('rimBtn'); if (b) b.textContent = rimOn ? '림 라이트 켜짐' : '림 라이트 꺼짐';
  if (!init) { pausedDrawn = false; pauseScene = false; }
}
const _rimC = new THREE.Color(), _rimL = new THREE.Vector3();
function postUniforms() {   // 아웃포커싱·림·복셀 안개: 화면 → 월드 행렬, 흐르는 시간(게임 시간: 멈추면 같이 멈춘다)
  const u = postMat.uniforms;
  camera.updateMatrixWorld();
  if (rimOn) { // 림 라이트: 방향(주광을 화면에 비춘 쪽 또는 시계, 큰 축이 1픽셀이 되게)·두께(외곽선이 있으면 한 칸 안쪽까지)·색(주광 색 × 세기)·주변 광원
    if (!u.tHgt.value) u.tHgt.value = hgtTex();
    u.uInvPV.value.copy(camera.matrixWorld).multiply(_vfM.copy(camera.projectionMatrix).invert());
    u.uView.value.copy(camera.matrixWorldInverse);
    let x, y, face = 1;
    if (RIM.follow === 'clock') { const a = (RIM.clock ?? 1.5) * Math.PI / 6; x = Math.sin(a); y = Math.cos(a); }
    else {   // 주광 쪽(월드)을 카메라 기준으로: 화면 오른쪽·위 성분. 화면에서 짧으면(빛이 카메라 앞·뒤) 그만큼 약하게
      _rimL.copy(moon.position).sub(moon.target.position).normalize().transformDirection(camera.matrixWorldInverse);
      x = _rimL.x; y = Math.max(_rimL.y, RIM.minUp ?? 0);   // 위쪽 성분 최소값: 빛을 등져도 위 가장자리 림이 남게
      face =Math.max(RIM.minFacing ?? 0.4, Math.hypot(x, y));
    }
    const k = 1 / Math.max(Math.abs(x), Math.abs(y), 1e-3);
    u.uRimDir.value.set(x * k, y * k);
    u.uRimW.value = Math.max(1, Math.round(RIM.width ?? 1)) + (outlineOn ? 1 : 0);
    _rimC.copy(moon.color).multiplyScalar(moon.intensity * face);
    u.uRimC.value.set(_rimC.r, _rimC.g, _rimC.b).multiplyScalar(RIM.strength ?? 0.35);
    u.uRimA.value.set(_rimC.r, _rimC.g, _rimC.b).multiplyScalar(RIM.add ?? 0.04);
    const fx = RIM.fx ?? 1.2, ref = Math.max(1, RIM.fxRef ?? 300);
    fxLights.forEach((l, i) => {   // 폭발·섬광·불빛 (21_grass_fx.js의 광원 4개, 30_combat.js가 매 프레임 채운다)
      const on = fx > 0 && l.intensity > 0 && l.distance > 0;
      u.uFxR.value[i] = on ? l.distance : 0;
      if (!on) return;
      u.uFxP.value[i].copy(l.position);
      const s = fx * (1 - Math.exp(-l.intensity / ref));
      u.uFxC.value[i].set(l.color.r * s, l.color.g * s, l.color.b * s);
    });
  }
  u.uRim.value = rimOn ? 1 : 0;
  // 아웃포커싱 세기: 타이틀 → 플레이(titleK) → 임무 완료(clearSeq.k)로 섞는다. 초점은 내 탱크까지 거리
  const dA = TITLE_DOF, dB = CAMV.dof, dC = CLR_CAM.dof, ck = clearSeq ? clearSeq.k : 0, dm = (a) => lerp(lerp(dA[a], dB[a], titleK), dC[a], ck);   // 타이틀 → 플레이(카메라 모드) → 임무 완료
  u.uDof.value = dm('strength'); u.uFocusR.value = dm('range'); u.uFocusF.value = Math.max(0.1, dm('fall')); u.uDofPx.value = dm('px');
  if (u.uDof.value > 0) u.uFocus.value = camera.position.distanceTo(_dofT.copy(tank.pos).setY(tank.pos.y + 0.6));
  u.uVF.value = vfOn ? titleK : 0;   // 타이틀에서는 안 보이고 플레이로 넘어가며 나타난다
  if (!vfOn) return;
  u.uInvPV.value.copy(camera.matrixWorld).multiply(_vfM.copy(camera.projectionMatrix).invert());
  u.uCamP.value.setFromMatrixPosition(camera.matrixWorld);
  u.uVFT.value = playTime * VF.speed * VF.scale * 4;
};
function setVoxelFog(v) { vfOn = v; if (v) vfInit(); else vfReset(); $el('vfBtn').textContent = v ? '복셀 안개 켜짐' : '복셀 안개 꺼짐'; pausedDrawn = false; pauseScene = false; }
if (vfOn) vfInit();   // config에서 켜 두었으면 처음부터
$el('vfBtn').onclick = (e) => { setVoxelFog(!vfOn); e.target.blur(); };
// 화면으로 늘리기: 후처리(디더링·32단계 색)까지는 게임 해상도 버퍼(postRT)에서 끝내고, 마지막에 기기 픽셀 크기 캔버스로 옮긴다.
// 샤프 바이리니어: 정수 배까지는 니어리스트처럼 또렷하게, 남는 소수 배만 경계에서 부드럽게 (픽셀마다 텍스처 한 번, 하드웨어 선형 필터)
const postRT = new THREE.WebGLRenderTarget(2, 2, { magFilter: THREE.LinearFilter, minFilter: THREE.LinearFilter, depthBuffer: false });
const upMat = new THREE.ShaderMaterial({
  uniforms: { tSrc: { value: postRT.texture }, uSrc: { value: new THREE.Vector2(2, 2) }, uK: { value: 1 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: `
    uniform sampler2D tSrc; uniform vec2 uSrc; uniform float uK; varying vec2 vUv;
    void main() {
      vec2 t = vUv * uSrc, c = fract(t) - 0.5, r = vec2(0.5 - 0.5 / uK);   // uK = 정수 배율 (화면 픽셀 ÷ 게임 픽셀의 정수 부분)
      gl_FragColor = texture2D(tSrc, (floor(t) + (c - clamp(c, -r, r)) * uK + 0.5) / uSrc);
    }`,
  depthTest: false, depthWrite: false,
});
const upScene = new THREE.Scene();
upScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), upMat));

// 화면 환경 두 벌: 타이틀(밝은 낮, 가까운 흰 안개, 위쪽 흰 그라데이션)과 플레이(밤. 설정 메뉴 값). titleK로 섞는다 (0 = 타이틀, 1 = 플레이)
const TT = CFG.title || {};
const BG_DARK = CFG.map.bgDark ?? 0.25;   // 맵 셋팅에 bgColor가 없을 때 하늘을 안개색보다 이만큼 어둡게
const _bgT = {}, bgDarken = (c) => { c.getRGB(_bgT, THREE.SRGBColorSpace); return c.setRGB(_bgT.r * (1 - BG_DARK), _bgT.g * (1 - BG_DARK), _bgT.b * (1 - BG_DARK), THREE.SRGBColorSpace); };   // (보이는 밝기로 어둡게)
const bgOf = (p, out) => p.bgColor ? out.set(p.bgColor) : bgDarken(out.set(p.fogColor ?? '#000000'));   // 그 셋팅의 하늘색
const ENV_PLAY = { bg: new THREE.Color(), bgAuto: !MAP0.bgColor, fog: new THREE.Color(MAP0.fogColor), near: 0, far: 2 / MAP0.fog, moon: MAP0.moon, moonC: new THREE.Color(MAP0.moonColor),
  sky: MAP0.sky, skyC: new THREE.Color(MAP0.skyColor), gndC: new THREE.Color(MAP0.groundColor), grad: 0 };
const ENV_TITLE = { fog: new THREE.Color(TT.fogColor ?? '#ffffff'), near: TT.fogNear ?? 20, far: TT.fogFar ?? 60, moon: TT.moon ?? 2.6, moonC: new THREE.Color(TT.moonColor ?? '#fff2dc'),
  sky: TT.sky ?? 2.2, skyC: new THREE.Color(TT.skyColor ?? '#eef2f8'), gndC: new THREE.Color(TT.groundColor ?? '#8a7a62'), grad: TT.gradient?.strength ?? 1 };
postMat.uniforms.uGradA.value = TT.gradient?.from ?? 0.64; postMat.uniforms.uGradB.value = TT.gradient?.to ?? 0.9;
postMat.uniforms.uGradC.value.copy(ENV_TITLE.fog);
let titleK = TT.enabled === false ? 1 : 0;
let clearSeq = null;   // 임무 완료 연출 { t, k(카메라·조명 0~1), cut(배경 지움 0~1), ... } (52_clear.js)
try { if (sessionStorage.getItem('MightyMolly.skipTitle')) { sessionStorage.removeItem('MightyMolly.skipTitle'); titleK = 1; } } catch (_) {}   // '새로 시작'으로 다시 읽었으면 타이틀 없이
function applyEnv() {
  const A = ENV_TITLE, B = ENV_PLAY, k = titleK;
  FOG.lerpColors(A.fog, B.fog, k); scene.fog.color.copy(FOG);
  if (B.bgAuto) bgDarken(B.bg.copy(B.fog));   // (bgColor 없는 셋팅: 안개색 슬라이더를 따라간다)
  SKY.lerpColors(A.fog, B.bg, k);   // 하늘: 타이틀은 타이틀 안개색 그대로
  scene.fog.near = FOGN.value = lerp(A.near, B.near, k); scene.fog.far = FOGF.value = lerp(A.far, B.far / Math.max(0.01, CAMV.fog), k);   // (플레이 안개 짙기 × 카메라 모드 fog)
  moon.intensity = lerp(A.moon, B.moon * CAMV.moon, k); moon.color.lerpColors(A.moonC, B.moonC, k);
  hemi.intensity = lerp(A.sky, B.sky, k); hemi.color.lerpColors(A.skyC, B.skyC, k); hemi.groundColor.lerpColors(A.gndC, B.gndC, k);
  postMat.uniforms.uGrad.value = lerp(A.grad, B.grad, k);
  if (clearSeq && clearSeq.k > 0) {   // 임무 완료: 주광·하늘빛을 타이틀 조명으로 (52_clear.js)
    const c = clearSeq.k;
    moon.intensity = lerp(moon.intensity, A.moon, c); moon.color.lerp(A.moonC, c);
    hemi.intensity = lerp(hemi.intensity, A.sky, c); hemi.color.lerp(A.skyC, c); hemi.groundColor.lerp(A.gndC, c);
  }
}
bgOf(MAP0, ENV_PLAY.bg);
applyEnv();

let resMax = false;   // 해상도 '최대': 화면 픽셀 그대로
let pixelPerfect = false;   // 게임 화면 한 픽셀 = 화면 픽셀 정수 배 (남는 곳은 검게)
// 화면 비율 제한: 가로:세로가 screen.aspectMin~aspectMax(1:1~2:1) 밖이면 넘치는 쪽을 잘라 내고, 남는 곳은 검은 레터박스.
// VR = 게임 화면이 차지하는 창 안의 사각형 (CSS 픽셀). 게임 캔버스와 픽셀 HUD를 그 자리에 놓는다
const SCR = CFG.screen || {}, VR = { x: 0, y: 0, w: 1, h: 1 };
function viewRect() {
  const W = innerWidth, H = innerHeight, a = Math.min(SCR.aspectMax ?? 2, Math.max(SCR.aspectMin ?? 1, W / H));
  VR.w = Math.min(W, Math.round(H * a)); VR.h = Math.min(H, Math.round(W / a));
  VR.x = Math.floor((W - VR.w) / 2); VR.y = Math.floor((H - VR.h) / 2);
  // Pixel Perfect: 게임 화면 한 픽셀 = 기기 픽셀 k×k (k는 정수). 해상도 설정은 세로 줄 수(lowH)만 정하므로 세로만 맞춘다:
  // 높이는 lowH × k (창에 들어가는 가장 큰 k, 남는 위아래는 검게), 가로는 그 높이에서 화면 비율 범위 안으로 창을 꽉 채우되 k의 배수로
  if (pixelPerfect && !resMax) {
    const dpr = devicePixelRatio || 1, k = Math.max(1, Math.floor(VR.h * dpr / lowH)), h = lowH * k / dpr;
    const rw = Math.max(2, Math.floor(Math.min(W, h * (SCR.aspectMax ?? 2)) * dpr / k));
    VR.w = rw * k / dpr; VR.h = h;
    VR.x = Math.round((W * dpr - rw * k) / 2) / dpr; VR.y = Math.round((H * dpr - lowH * k) / 2) / dpr;
  }
  for (const el of [renderer.domElement, $el('phud'), $el('phudS'), $el('pui'), $el('puiS'), $el('title')])
    if (el) Object.assign(el.style, { left: `${VR.x}px`, top: `${VR.y}px`, width: `${VR.w}px`, height: `${VR.h}px` });
  layoutTitle();
}
// 타이틀 네 귀퉁이: 좌상 로고, 우상 브랜드, 좌하 배지(옆에 버전·빌드), 우하 안내. 모두 게임 픽셀 단위 도트 그림(_src)이고
// HUD와 같은 배율(해상도 360줄마다 1배씩)로 늘린다. 버전·빌드는 배지 옆에 자리가 없으면 배지 위로
function layoutTitle() {
  const el = (id) => $el(id);
  if (!el('tLogo') || !el('tLogo')._src || !el('tPress')._src) return;
  const u = Math.max(1, Math.floor(lowH / 360)) * VR.h / lowH, m = 10 * u;   // u = 게임 픽셀 한 칸의 CSS 크기
  const put = (id, side, v, dx = 0, dy = 0) => {
    const c = el(id);
    c._css = [c._src.width * u, c._src.height * u];   // 사라질 때 다시 그리려고 보관
    Object.assign(c.style, { left: '', right: '', top: '', bottom: '', [side]: `${m + dx}px`, [v]: `${m + dy}px` });
    titleWipe(c);   // 사라지는 중이면 그 정도로
    return c._src.width * u;
  };
  put('tLogo', 'left', 'top'); put('tBrand', 'right', 'top');
  // 아래 요소들은 오른쪽 아래로 1칸 그림자가 있다: 여백 10칸은 그림자를 빼고 잰다
  // 맨 아래 위장색·데칼·설정 안내, 그 위에 게임 시작 (줄 간격 15칸)
  const camoH = el('tCamo') && el('tCamo')._src ? (put('tCamo', 'right', 'bottom', -u, -u), el('tCamo')._src.height * u + 2 * u) : 0;   // 한글 줄 높이 15칸에 맞춰 (안내 4줄이 한 목록처럼)
  const bw = put('tBadge', 'left', 'bottom', 0, -u), pw = put('tPress', 'right', 'bottom', -u, -u + camoH + 3 * u);   // (시작 버튼과 아래 안내 사이 3칸 더)
  const vw = el('tVer')._src.width * u, vx = bw + 6 * u;
  if (m + vx + vw + 10 * u + pw + m <= VR.w) put('tVer', 'left', 'bottom', vx, -u);
  else put('tVer', 'left', 'bottom', 0, el('tBadge')._src.height * u + 4 * u - u);
}
let paused = false, pausedDrawn = false, pauseScene = false;   // pauseScene: 멈춘 뒤 장면을 한 번 그렸다 (그 뒤로는 HUD·창·회색조만 다시 그린다)   // 일시정지 (창이 비활성이거나 ESC). 멈춘 직후 한 번만 다시 그린다
function resize() {
  if (!innerWidth || !innerHeight) return;   // 창이 접혀 크기가 0이면 다음 크기 변경 때
  viewRect();
  if (resMax) lowH = Math.round(VR.h * (devicePixelRatio || 1));
  layerScale = crtOn ? lowH / VR.h : 0;   // CRT 표현: HUD·UI를 게임 픽셀 크기로 (00_core.js)
  const w = Math.max(2, Math.round(lowH * VR.w / VR.h)), dpr = crtOn ? crtDpr() : devicePixelRatio || 1, dw = Math.max(2, Math.round(VR.w * dpr)), dh = Math.max(2, Math.round(VR.h * dpr));   // CRT는 crt.maxScale 배율까지만
  renderer.setSize(dw, dh, false);   // 캔버스는 기기 픽셀 크기 (게임은 rt에 저해상도로 그리고 마지막에 늘린다)
  rt.setSize(w, lowH); cutRT.setSize(w, lowH); olRT.setSize(w, lowH); preRT.setSize(w, lowH); postRT.setSize(w, lowH);
  upMat.uniforms.uSrc.value.set(w, lowH); upMat.uniforms.uK.value = Math.max(1, Math.floor(dh / lowH + 1e-6));
  postMat.uniforms.uTexel.value.set(1 / w, 1 / lowH);
  U.uSnap.value.set(w / 2, lowH / 2);
  camera.aspect = w / lowH; camera.updateProjectionMatrix();
  U.uPointScale.value = lowH / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)));
  layoutTitle();   // 해상도가 바뀌면 타이틀 그림도 다시
  pausedDrawn = false; pauseScene = false;   // 멈춰 있어도 바뀐 크기로 한 번 다시 그린다 (장면까지)
}
addEventListener('resize', resize);
$el('res').onchange = (e) => { resMax = e.target.value === 'max'; if (!resMax) lowH = +e.target.value; resize(); e.target.blur(); };
$el('olBtn').onclick = (e) => { setOutlineMode(OL_MODES[(OL_MODES.indexOf(olMode) + 1) % OL_MODES.length]); e.target.blur(); };   // 외곽선 (풀 제외): 끔 → 켬(아웃포커싱) → 켬(흐린 곳 디더링)
$el('rimBtn').onclick = (e) => { setRim(!rimOn); e.target.blur(); };
$el('toonBtn').onclick = (e) => { setToon(!toonOn); if (typeof pausedDrawn !== 'undefined') { pausedDrawn = false; pauseScene = false; } e.target.blur(); };
setOutlineMode(olMode, true); setRim(rimOn, true); setToon(toonOn);
let grassMode = 0;   // 텍스처 종류 (0부터). grassCardMats.length = 풀 끔 (성능 비교용: 메시만 숨긴다)
function setGrass(m) {
  grassMode = m;
  const off = m >= grassCardMats.length;
  for (const cm of grassCard) { cm.visible = !off; if (!off) cm.material = grassCardMats[m]; }
  $el('grassBtn').textContent = off ? '풀: 끔' : `풀: 텍스처${grassCardNames[m]}`;
}
$el('grassBtn').onclick = (e) => { setGrass((grassMode + 1) % (grassCardMats.length + 1)); e.target.blur(); };   // 텍스처1 → 2 → 3 → 끔 → 1
setGrass(1);   // 처음엔 텍스처2 (이삭 풀)
$el('ppBtn').onclick = (e) => {
  pixelPerfect = !pixelPerfect; e.target.textContent = pixelPerfect ? 'Pixel Perfect 켜짐' : 'Pixel Perfect 꺼짐';
  resize(); e.target.blur();
};
$el('aaBtn').onclick = (e) => {   // 안티에일리어싱: 저해상도 화면 버퍼를 4배 다중 샘플로
  rt.samples = rt.samples ? 0 : 4; rt.dispose();
  e.target.textContent = rt.samples ? 'AA 켜짐' : 'AA 꺼짐'; e.target.blur();
};
$el('camModeBtn').onclick = (e) => {   // 보는 방향 기준: 자동 → 차체 → 포탑 → 자동
  setCamMode(CAM_MODES[(CAM_MODES.indexOf(camMode) + 1) % CAM_MODES.length]); e.target.blur();
};
$el('fogC').oninput = (e) => { ENV_PLAY.fog.set(e.target.value); applyEnv(); };
$el('fogC').onchange = (e) => e.target.blur();
$el('vol').oninput = (e) => setVolume(+e.target.value);
$el('debris').oninput = (e) => { windDebris = +e.target.value; $el('debrisV').textContent = windDebris.toFixed(2); };
for (const id of ['vol', 'debris']) $el(id).onchange = (e) => e.target.blur();
// 성장 테스트: 상자·적 떨구기 (내 탱크 둘레 12~32m), 내 탱크 성능 슬라이더 (오른쪽일수록 강하게)
$el('tDropGold').onclick = (e) => { dropSafe('gold', tank.pos); e.target.blur(); };
$el('tDropRepair').onclick = (e) => { dropSafe('repair', tank.pos); e.target.blur(); };
for (const lv of [1, 2, 3]) $el('tDropEnemy' + lv).onclick = (e) => { startDrop(newEnemy(false, Math.min(EC.clearKills, enemyDrops + 2), lv), tank.pos); e.target.blur(); };   // 적 탱크 레벨 1~3   // 다음 순번 레벨로
$el('tDropSpg').onclick = (e) => { spawnSpg(); e.target.blur(); };
$el('tDropJeep').onclick = (e) => { startDrop(newJeep()); e.target.blur(); };
// 슬라이더: [id, 최소, 최대(config의 최대값), 처음 값(config), 적용]. 재장전은 짧을수록 오른쪽이 되게 음수로
const GROW = [
  ['gReload', -8, -PM.reloadMin, -PC.reload, (v) => { tank.reload = -v; return `${(-v).toFixed(1)}초`; }],
  ['gMuzzle', 8, PM.muzzle, PC.muzzle, (v) => { tank.muzzle = v; return `${v.toFixed(1)}m/s`; }],
  ['gDmg', 20, PM.shellDamage, PC.shellDamage, (v) => { tank.shellDmg = v; return `${Math.round(v)}`; }],
  ['gSplash', 0, PM.blastRadius, PC.blastRadius, (v) => { tank.blastR = v; return `${v.toFixed(1)}m`; }],
  ['gBlastDmg', 0, PM.blastRatio, PC.blastRatio, (v) => { tank.blastRatio = v; return `${Math.round(v * 100)}%`; }],
  ['gAcc', 2, PM.accel, PC.accel, (v) => { tank.accM = v / ACC; return `${v.toFixed(2)}m/s²`; }],
  ['gSpd', 3, PM.maxSpeed, PC.maxSpeed, (v) => { tank.spdM = v / VMAX; return `${(v * 3.6).toFixed(0)}km/h`; }],
  ['gTurn', 20, PM.turnRate, PC.turnRate, (v) => { tank.turnM = v / PC.turnRate; return `${Math.round(v)}°/s`; }],
  ['gTurret', 15, PM.turretRate, PC.turretRate, (v) => { tank.turretRate = v * DEG; return `${Math.round(v)}°/s`; }],
];
for (const [id, min, max, init, apply] of GROW) {
  const el = $el(id), lab = $el(id + 'V');
  el.min = min; el.max = max; el.value = el.defaultValue = init;
  el.oninput = () => { lab.textContent = apply(+el.value); };
  el.onchange = () => el.blur();
  el.oninput();
}
// 기관총 (내 탱크에 기관총이 있을 때만): 초당 발사 수 · 대미지. 성장으로 바뀌면 dbgSync가 따라 맞춘다
const mgSl = [['gMgRate', 1, Math.max(PM.mgRate, 30), (v) => { if (tank.mg) tank.mg.rate = v; return `${v}발/초`; }], ['gMgDmg', 1, Math.max(PM.mgDamage, 40), (v) => { if (tank.mg) tank.mg.damage = v; return `${v}`; }]];
for (const [id, min, max, apply] of mgSl) { const el = $el(id); el.min = min; el.max = max; el.oninput = () => { $el(id + 'V').textContent = apply(+el.value); }; el.onchange = () => el.blur(); }
$el('gMgAdd').onclick = (e) => { UP_FX.mg.apply(); dbgSync(); e.target.blur(); };   // 기관총 하나 더 (최대 2정)
$el('gRegen').oninput = (e) => { tank.regen = +e.target.value; $el('gRegenV').textContent = `${tank.regen}`; };
$el('gRegen').onchange = (e) => e.target.blur();
// 무적: 내 탱크가 맞아도 체력이 줄지 않는다 (damageTank)
let godMode = false;
$el('gGod').onclick = (e) => { godMode = !godMode; e.target.textContent = godMode ? '무적 켜짐' : '무적 꺼짐'; e.target.blur(); };
// 설정 메뉴 버튼·게이지 상태 맞추기 (메뉴가 열려 있을 때 0.2초마다): 할 수 없는 것은 흐리게
function dbgSync() {
  const mg = tank.mg, n = mg ? mg.count : 0;
  const add = $el('gMgAdd'); add.disabled = n >= 2; add.textContent = n >= 2 ? '기관총 추가 (최대 2정)' : `기관총 추가 (${n}정)`;
  for (const [id, , , apply] of mgSl) {
    const el = $el(id); el.disabled = !mg;
    if (mg && document.activeElement !== el) { el.value = id === 'gMgRate' ? mg.rate : mg.damage; $el(id + 'V').textContent = apply(+el.value); }
    if (!mg) $el(id + 'V').textContent = '없음';
  }
}
const sliderAt = (id) => { const el = $el(id); return +el.value >= +el.max - 1e-6; };   // 최대값에 닿았는가
// 성장으로 바뀌는 내 탱크 값을 모두 처음으로 (슬라이더 + 고른 성장 항목)
function resetGrowth() {
  for (const [id] of GROW) { const el = $el(id); el.value = el.defaultValue; el.oninput(); }
  Object.assign(tank, { maxHp: PC.hp, hp: Math.min(tank.hp, PC.hp), magnetR: MAGNET_R, armorM: 1, goldMul: 1, pierce: 0, ram: false, waterSpeed: undefined, goldKeep: false, autoRepair: false, repairAcc: 0, mg: null, picks: {}, pickLog: [],
    berserk: 0, coinMul: 1, combos: [], apMg: false, dozer: 0, fieldRepair: false, scrap: 0, sniper: 0,
    bunkerMul: 1, kitMul: 1, supplyBlast: null, twin: 0, twinT: 0, crit: 0, critMul: 2, offerN: 3 });
  comboQueue.length = 0;
  drawPickLog();
  showGuns(0);
  growLevel = 0;
}
$el('gReset').onclick = (e) => { resetGrowth(); e.target.blur(); };
// 성장 선택지: 골드가 100(설정)개 모이면 3개 중 하나 (게임은 멈추지 않는다). 우상단에 픽셀 UI로 세로로 뜨고 (offerUI),
// 숫자키 1·2·3, 게임패드 방향키 ←·↑·→, 또는 항목을 눌러 고른다.
// 고르면 골드 100을 내고, 나머지는 곧바로 어두운 회색이 됐다가 잠시 뒤 모두 4x4 디더링으로 사라진다. 그래도 100개 이상 남았으면 이어서 다음 선택지.
// 선택지는 레어도 가중치(일반 100 / 고급 70 / 희귀 30 / 전설 10, 설정)로 겹치지 않게 뽑는다
// 성장 한 번에 드는 골드: 0~9단계는 100, 10~19단계는 200, … (설정)
const GC = CFG.growth, offerCost = () => GC.goldPerOffer + Math.floor(growLevel / GC.goldStepEvery) * GC.goldStepAdd;
const bumpSlider = (id, f) => { const el = $el(id); el.value = Math.max(+el.min, Math.min(+el.max, f(+el.value))); el.oninput(); };
// 항목별 효과 (v = config의 value)와 지금 고를 수 있는지
const UP_FX = {
  speed:      { apply: (v) => bumpSlider('gSpd', x => x * (1 + v / 100)), ok: () => !sliderAt('gSpd') },
  accel:      { apply: (v) => bumpSlider('gAcc', x => x * (1 + v / 100)), ok: () => !sliderAt('gAcc') },
  turn:       { apply: (v) => bumpSlider('gTurn', x => x * (1 + v / 100)), ok: () => !sliderAt('gTurn') },
  turret:     { apply: (v) => bumpSlider('gTurret', x => x * (1 + v / 100)), ok: () => !sliderAt('gTurret') },
  reload:     { apply: (v) => bumpSlider('gReload', x => x * (1 - v / 100)), ok: () => !sliderAt('gReload') },
  muzzle:     { apply: (v) => bumpSlider('gMuzzle', x => x * (1 + v / 100)), ok: () => !sliderAt('gMuzzle') },
  damage:     { apply: (v) => bumpSlider('gDmg', x => x * (1 + v / 100)), ok: () => !sliderAt('gDmg') },
  blast:      { apply: (v) => bumpSlider('gSplash', x => x + v), ok: () => !sliderAt('gSplash') },
  blastDmg:   { apply: (v) => bumpSlider('gBlastDmg', x => x + v / 100), ok: () => tank.blastR > 0 && !sliderAt('gBlastDmg') },   // 폭발 범위가 있을 때만
  magnet:     { apply: (v) => { tank.magnetR = Math.min(PM.magnetRange, tank.magnetR * (1 + v / 100)); }, ok: () => tank.magnetR < PM.magnetRange },
  armor:      { apply: (v) => { tank.armorM = Math.max(PM.armorMul, tank.armorM * (1 - v / 100)); }, ok: () => tank.armorM > PM.armorMul + 1e-6 },
  heal:       { apply: () => { tank.hp = tank.maxHp; } },   // 최대 HP까지 완전히 수리
  maxHp:      { apply: (v) => { tank.maxHp += v; tank.hp += v; } },
  ram:        { apply: () => { tank.ram = true; } },
  water:      { apply: () => { tank.waterSpeed = 1; } },
  gold:       { apply: () => { tank.goldMul++; }, ok: () => tank.goldMul < PM.goldMul },
  goldKeep:   { apply: () => { tank.goldKeep = true; } },
  mg:         { apply: () => { if (tank.mg) tank.mg.count = 2; else tank.mg = { rate: PC.mg.rate, damage: PC.mg.damage, range: PC.mg.range, count: 1 }; showGuns(tank.mg.count); } },   // 두 번째는 포탑 왼쪽에
  mgRange:    { apply: (v) => { tank.mg.range = Math.min(PM.mgRange, tank.mg.range + v); }, ok: () => tank.mg && tank.mg.range < PM.mgRange },
  mgRate:     { apply: (v) => { tank.mg.rate = Math.min(PM.mgRate, tank.mg.rate + v); }, ok: () => tank.mg && tank.mg.rate < PM.mgRate },
  mgDmg:      { apply: (v) => { tank.mg.damage = Math.min(PM.mgDamage, tank.mg.damage + v); }, ok: () => tank.mg && tank.mg.damage < PM.mgDamage },
  pierce:     { apply: (v) => { tank.pierce += v / 100; } },
  superPierce:{ apply: (v) => { tank.pierce += v / 100; } },
  autoRepair: { apply: () => { tank.autoRepair = true; tank.repairAcc = 0; } },
  bunkerBuster:{ apply: (v) => { tank.bunkerMul = (tank.bunkerMul || 1) + v / 100; }, ok: () => BUNKERS.some((B) => !B.ruin) },   // 남은 벙커가 있을 때만
  repairKit:  { apply: (v) => { tank.kitMul = v || 2; } },
  supplyBlast:{ apply: () => { const u = GC.upgrades.find((x) => x.id === 'supplyBlast') || {}; tank.supplyBlast = { r: u.explodeRadius ?? 10, d: u.explodeDamage ?? 200 }; } },
  twin:       { apply: (v) => { tank.twin = v || 0.15; } },
  crit:       { apply: (v, w) => { tank.crit = (v ?? 20) / 100; tank.critMul = w || 2; } },
  // 위험 (v = 장점, w = 단점의 양)
  glass:      { apply: (v, w) => { bumpSlider('gDmg', x => x * (1 + v / 100)); tank.maxHp = Math.max(1, Math.round(tank.maxHp * (1 - w / 100))); tank.hp = Math.min(tank.hp, tank.maxHp); } },
  light:      { apply: (v, w) => { bumpSlider('gSpd', x => x * (1 + v / 100)); bumpSlider('gAcc', x => x * (1 + v / 100)); tank.armorM *= 1 + w / 100; } },
  heavy:      { apply: (v, w) => { tank.armorM *= 1 - v / 100; bumpSlider('gSpd', x => x * (1 - w / 100)); bumpSlider('gTurn', x => x * (1 - w / 100)); } },   // 장갑 강화 최대값보다 더 내려갈 수 있다
  rapid:      { apply: (v, w) => { bumpSlider('gReload', x => x * (1 - v / 100)); bumpSlider('gDmg', x => x * (1 - w / 100)); } },
  berserk:    { apply: (v) => { tank.berserk = v / 100; } },
  wide:       { apply: (v) => { tank.offerN = Math.min(4, 3 + (v || 1)); } },   // '폭넓은 선택': 다음부터 선택지 4개 (화면·키는 4개까지)
  greed:      { apply: (v, w) => { tank.coinMul = 2; tank.magnetR *= 1 - w / 100; } },
};
const upText = (s, u) => s.replaceAll('{v}', u.value ?? '').replaceAll('{w}', u.value2 ?? '').replaceAll('{n}', tank.goldMul + 1);
// 이번에 고르면 마지막 단계인가: 고를 수 있는 횟수(max)를 다 채우거나, 성능이 최대값에 닿는다
const willMax = (id, f) => { const el = $el(id); return f(+el.value) >= +el.max - 1e-6; };
const UP_LAST = {
  speed: (v) => willMax('gSpd', x => x * (1 + v / 100)), accel: (v) => willMax('gAcc', x => x * (1 + v / 100)), turn: (v) => willMax('gTurn', x => x * (1 + v / 100)),
  turret: (v) => willMax('gTurret', x => x * (1 + v / 100)), reload: (v) => willMax('gReload', x => x * (1 - v / 100)), muzzle: (v) => willMax('gMuzzle', x => x * (1 + v / 100)),
  damage: (v) => willMax('gDmg', x => x * (1 + v / 100)), blast: (v) => willMax('gSplash', x => x + v), blastDmg: (v) => willMax('gBlastDmg', x => x + v / 100),
  magnet: (v) => tank.magnetR * (1 + v / 100) >= PM.magnetRange, armor: (v) => tank.armorM * (1 - v / 100) <= PM.armorMul + 1e-6, gold: () => tank.goldMul + 1 >= PM.goldMul,
  mgRate: (v) => tank.mg.rate + v >= PM.mgRate, mgDmg: (v) => tank.mg.damage + v >= PM.mgDamage, mgRange: (v) => tank.mg.range + v >= PM.mgRange,
};
const upLast = (u) => (u.max > 1 && (tank.picks[u.id] || 0) + 1 >= u.max) || (UP_LAST[u.id] ? UP_LAST[u.id](u.value) : false);
const upAvail = (u) => { const fx = UP_FX[u.id]; return fx && (u.max == null || (tank.picks[u.id] || 0) < u.max) && (!fx.ok || fx.ok()); };
const upWeight = (u) => (GC.rarity[u.rarity] ? GC.rarity[u.rarity].weight : 0) * (u.weight ?? 1);
// 레어도 조건: minLevel(이번 선택지의 LV가 이 이상일 때만), perOffer(한 번에 이 개수까지. '위험'은 1개)
const rarityOk = (u, out) => { const R = GC.rarity[u.rarity] || {}; return growLevel + 1 >= (R.minLevel ?? 0) && out.filter((o) => o.rarity === u.rarity).length < (R.perOffer ?? 3); };
function rollChoices() {
  const pool = GC.upgrades.filter(u => upAvail(u) && upWeight(u) > 0), out = [];
  for (;;) {
    for (let i = pool.length - 1; i >= 0; i--) if (!rarityOk(pool[i], out)) pool.splice(i, 1);
    if (out.length >= (tank.offerN || 3) || !pool.length) break;
    let r = Math.random() * pool.reduce((s, u) => s + upWeight(u), 0), k = 0;
    while (k < pool.length - 1 && (r -= upWeight(pool[k])) > 0) k++;
    out.push(pool.splice(k, 1)[0]);
  }
  return out.map(u => ({ u, label: upText(u.name, u), desc: upText(u.desc, u) + (upLast(u) ? ' (최대)' : ''), bad: u.bad ? upText(u.bad, u) : '' }));
}
// ---- 조합 보너스: need의 성장을 모두 갖추면 열린다. 고른 순간 효과가 들어가고, 선택지가 사라진 뒤 카드로 알린다 (comboQueue)
const COMBOS = GC.combos || [];
const COMBO_FX = {
  apMg: () => { tank.apMg = true; },
  dozer: (v) => { tank.dozer = v || 2; },
  fieldRepair: () => { tank.fieldRepair = true; },
  scrap: (v) => { tank.scrap = v || 1; },
  sniper: (v) => { tank.sniper = (v || 80) / 100; },
};
const comboQueue = [];
const needCount = (picks, k) => k.split('|').reduce((n, id) => n + (picks[id] || 0), 0);
const comboReady = (C, picks) => Object.entries(C.need || {}).every(([k, n]) => needCount(picks, k) >= n);
// 조합이 열린 이유: '자석 3회 + 골드 x3'
function comboReason(C) {
  return Object.entries(C.need || {}).map(([k, n]) => {
    const id = k.split('|')[0], u = GC.upgrades.find((x) => x.id === id), nm = u ? u.name : id;
    if (id === 'gold') return nm.replaceAll('{n}', n + 1);
    return n > 1 ? `${nm} ${n}회` : nm;
  }).join(' + ');
}
// 이 성장을 하나 더 고르면 새로 열리는 조합이 있는가 (선택지 카드의 '조합 완성' 표시)
const completesCombo = (u) => { const p = { ...tank.picks, [u.id]: (tank.picks[u.id] || 0) + 1 }; return COMBOS.some((C) => !(tank.combos || []).includes(C.id) && !comboReady(C, tank.picks) && comboReady(C, p)); };
function checkCombos() {
  for (const C of COMBOS) {
    if ((tank.combos || []).includes(C.id) || !comboReady(C, tank.picks)) continue;
    tank.combos.push(C.id);
    if (COMBO_FX[C.id]) COMBO_FX[C.id](C.value);
    const card = { u: { id: C.id, rarity: 'combo' }, label: C.name, desc: upText(C.desc, C), reason: comboReason(C), combo: true };
    tank.pickLog.push(card); comboQueue.push(card);
  }
}
let testOffers = 0, curOffer = null, growLevel = 0, heldOffer = null;   // curOffer.combo: 조합 완성 알림 카드 (choices 한 장, 고를 것 없음)   // heldOffer: 고르기 전에 터져서 접어 둔 선택지 (다시 착지하면 띄운다)
function drawOffer() { if (rulesLocked()) return; if (UI.screen !== offerUI) uiShow(offerUI); else uiDirty(); }   // 적군 섬멸 창은 성장 선택지로 바뀌지 않는다
// 다음 선택지: 테스트 버튼으로 예약한 것 먼저, 아니면 골드가 100 이상일 때
function nextOffer() {
  if (rulesLocked()) return;   // 적군 섬멸 창이 떠 있으면 선택지를 띄우지 않는다 (창이 선택지로 바뀌어 버린다)
  if (curOffer && curOffer.picked >= 0 && UI.screen !== offerUI) curOffer = null;   // 고른 선택지가 다른 창에 밀려 끝나지 못하고 남았으면 거둔다
  if (curOffer || heldOffer || !tank.solid) return;   // 터져 있거나 떨어지는 중이면 착지한 뒤에
  if (comboQueue.length) {   // 열린 조합이 있으면 그 카드부터 (고를 것 없이 잠시 보였다 사라진다)
    curOffer = { choices: [comboQueue.shift()], combo: true, picked: 0, showT: 0, pickT: -COMBO_HOLD };
    drawOffer(); sfx.ui('combo');
    return;
  }
  if (testOffers > 0) testOffers--;
  else if (gold < offerCost()) return;
  const choices = rollChoices();
  if (!choices.length) return;
  curOffer = { choices, picked: -1, showT: 0 };
  drawOffer();
  sfx.kit();
}
function goldGain(n) { if (rulesLocked()) return; gold += n; nextOffer(); }   // 섬멸 창 동안은 주워도 골드가 안 는다 (날아가는 모습은 그대로)
function pickOffer(i) {
  if (!curOffer || curOffer.picked >= 0 || !curOffer.choices[i]) return;
  curOffer.picked = i;
  const u = curOffer.choices[i].u;
  UP_FX[u.id].apply(u.value, u.value2);
  tank.picks[u.id] = (tank.picks[u.id] || 0) + 1;
  tank.pickLog.push(curOffer.choices[i]); checkCombos(); drawPickLog();
  if (!curOffer.paid) gold = Math.max(0, gold - offerCost());   // 성장 값으로 골드를 낸다 (고르기 전 단계 기준. 0 아래로는 안 내려감. 터질 때 미리 낸 선택지는 빼고)
  growLevel++;   // 테스트 버튼으로 띄운 선택지도 똑같이 한 단계
  curOffer.pickT = 0;   // 고른 뒤 흐른 시간 (offerUI.tick: 게임이 멈추면 같이 멈춘다)
  drawOffer();   // 나머지는 곧바로 어두운 회색
  sfx.coin();
}
// 고르기 전의 선택지를 거둔다 (처음부터 다시 할 때)
function cancelOffer() {
  heldOffer = null;
  if (!curOffer) return;
  curOffer = null; if (UI.screen === offerUI) uiShow(null);
}
// 내 탱크가 고르기 전에 터졌을 때: 선택지를 접어 둔다. 골드를 흩뿌릴 거라면 성장 값은 지금 미리 낸다 (흩뿌린 골드를 다시 주워 또 쓰지 않게)
function holdOffer(spill) {
  // 이미 고른 선택지가 사라지는 중이었다면: 효과는 이미 들어갔으니 그냥 거둔다 (남겨 두면 다음 선택지가 영영 안 뜬다)
  if (curOffer && curOffer.picked >= 0) { curOffer = null; if (UI.screen === offerUI) uiShow(null); return; }
  if (!curOffer) return;
  heldOffer = curOffer; curOffer = null;
  if (spill && !heldOffer.paid) { heldOffer.paid = true; gold = Math.max(0, gold - offerCost()); }
  if (UI.screen === offerUI) uiShow(null);
}
// 다시 떨어져 착지했을 때: 접어 둔 선택지를 처음처럼 띄우고, 없으면 골드가 모였는지 본다
function landOffer() {
  if (heldOffer) { curOffer = heldOffer; heldOffer = null; curOffer.showT = 0; drawOffer(); sfx.kit(); }
  else nextOffer();
}
addEventListener('keydown', (e) => { const m = /^(Digit|Numpad)([1-4])$/.exec(e.code); if (m && UI.screen === offerUI) pickOffer(+m[2] - 1); });   // 숫자 1~4 (위쪽 숫자 줄 또는 숫자 키패드. 4는 '폭넓은 선택'). 선택지가 보일 때만 (일시정지 창 아래에 있으면 안 됨)
$el('gOffer').onclick = (e) => { testOffers++; nextOffer(); e.target.blur(); };   // 테스트: 골드 없이 바로 선택지
// 테스트: 성장 10단계를 한 번에. 단계마다 평소처럼 선택지 3개를 뽑아 그중 하나를 무작위로 고른다 (골드는 쓰지 않음. 떠 있는 선택지는 그대로)
$el('gRand10').onclick = (e) => {
  for (let k = 0; k < 10; k++) {
    const ch = rollChoices();
    if (!ch.length) break;   // 더 고를 것이 없다
    const c = ch[Math.floor(Math.random() * ch.length)];
    UP_FX[c.u.id].apply(c.u.value, c.u.value2);
    tank.picks[c.u.id] = (tank.picks[c.u.id] || 0) + 1;
    tank.pickLog.push(c); checkCombos();
    growLevel++;
  }
  drawPickLog(); sfx.coin(); e.target.blur();
};
$el('gReroll').onclick = (e) => {   // 테스트: 떠 있는 선택지 3개를 확률대로 다시 뽑는다
  if (curOffer && curOffer.picked < 0) { curOffer.choices = rollChoices(); drawOffer(); }
  e.target.blur();
};
// 맵 설정의 처음 값 (config.js)
const setInput = (id, v) => { const el = $el(id); el.value = v; if (el.oninput) el.oninput({ target: el }); };
let windDir = MAP0.windDir;   // 바람이 불어 가는 쪽 (°): 0 = +x, 90 = +z(북쪽)
$el('windDir').value = windDir; $el('windDirV').textContent = `${windDir}°`;
$el('windDir').oninput = (e) => { windDir = +e.target.value; $el('windDirV').textContent = `${windDir}°`; };
$el('wind').oninput = (e) => { U.uWind.value = +e.target.value; $el('windV').textContent = (+e.target.value).toFixed(2); };
$el('wind').onchange = (e) => e.target.blur();
$el('fog').oninput = (e) => { ENV_PLAY.far = 2 / Math.max(1e-4, +e.target.value); applyEnv(); $el('fogV').textContent = (+e.target.value).toFixed(4); };
$el('fog').onchange = (e) => e.target.blur();
$el('cbox').onclick = (e) => { toggleCollisionView(); e.target.blur(); };
// 설정 메뉴: ` 키로 열고 닫는다 (늘 펼쳐진 상태)
const hudEl = $el('hud');
if (DEV) addEventListener('keydown', (e) => { if (e.code === 'Backquote' && e.shiftKey) { hudEl.style.display = hudEl.style.display === 'block' ? 'none' : 'block'; e.preventDefault(); } });   // 설정 메뉴: ~ (Shift + `. 숫자 1 옆이라 잘못 눌러 열리지 않게)
$el('camreset').onclick = (e) => { resetCamera(); e.target.blur(); };
// 마우스 오른쪽 끌기로 카메라 옮기기: 평소엔 끔 (설정 메뉴에서 켠다)
controls.enablePan = false;
$el('camPanBtn').onclick = (e) => { controls.enablePan = !controls.enablePan; e.target.textContent = controls.enablePan ? '우클릭 카메라 이동 켜짐' : '우클릭 카메라 이동 꺼짐'; e.target.blur(); };
// 자동 카메라 (설정, 기본 켜기): 마우스로 돌리거나 당긴 카메라가 손을 뗀 뒤 2초가 지나면 기본 방향·거리로 EaseInOutCubic(1.5초)으로 돌아온다.
// 끄면 바꾼 방향·거리를 그대로 둔다. camBack()을 frame이 부른다
const CAM_BACK_WAIT = 2000, CAM_BACK_T = 1.5;
let camDrag = false, camBackAt = 0, camRet = null;
controls.addEventListener('start', () => { camDrag = true; camBackAt = 0; camRet = null; });
controls.addEventListener('end', () => { camDrag = false; camBackAt = autoCam ? performance.now() + CAM_BACK_WAIT : 0; });
function camRetBegin(T) {   // 지금 자리에서 기본 방향·거리로 돌아가기 시작 (T: 걸리는 시간, 없으면 CAM_BACK_T)
  _tmp.copy(camera.position).sub(controls.target);
  const r = _tmp.length();
  camRet = { yaw: Math.atan2(-_tmp.x, -_tmp.z), pit: Math.asin(Math.max(-1, Math.min(1, _tmp.y / r))), r, t: 0, T };   // 돌아오기 시작한 자리
  camBackAt = 0; camElReset();   // (끌어 둔 어긋남도 함께 제자리로 가니 잊는다)
}
function camBack(dt) {
  if (camDrag || camEl.on || camPinch || (!autoCam && !(camRet && camRet.T))) return;   // 끄는 중(직접 처리하는 끌기·두 손가락 포함)에는 기다린다. (카메라 모드를 바꿀 때는 자동 카메라를 꺼도 옮긴다)
  if (!camRet) {
    if (!autoCam || !camBackAt || performance.now() < camBackAt) return;
    camRetBegin();
  }
  camRet.t += dt;
  const RT = camRet.T || CAM_BACK_T, e = easeInOutCubic(Math.min(1, camRet.t / RT));
  let dy = camYaw - camRet.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy));   // 기본 방향은 탱크를 따라 계속 바뀐다
  const yaw = camRet.yaw + dy * e, pit = camRet.pit + (CAMV.pitch * DEG - camRet.pit) * e, r = camRet.r + (CAMV.distance - camRet.r) * e;
  camera.position.copy(controls.target).add(_tmp.set(-Math.sin(yaw) * Math.cos(pit) * r, Math.sin(pit) * r, -Math.cos(yaw) * Math.cos(pit) * r));
  if (camRet.t >= RT) camRet = null;
}
// 끌어 돌리기·휠 거리 (카메라 모드 drag·dragHalf·zoom·zoomHalf). drag의 x = 가로(좌우로 도는 각), y = 세로(위아래):
//   true = 그 방향은 자유롭게, 손을 뗀 뒤부터 자동 카메라 설정대로 (켜져 있으면 CAM_BACK_WAIT 뒤 camBack이 CAM_BACK_T초에 걸쳐 제자리로, 꺼져 있으면 그대로)
//   숫자 L° = 러버밴딩: 끈 거리 r(화면 높이 단위)에 대해 보이는 각도 = L·r/(r + dragHalf) (끌수록 L에 끝없이 가까워진다). 놓으면 스프링으로 바로 튕겨 제자리
//   false·0 = 그 방향은 안 돎. 둘 다 true면 예전처럼 OrbitControls가 돌린다 (camBack이 되돌림)
// zoom: 'auto' = 휠 거리는 OrbitControls (min~maxDistance, 자동 카메라면 2초 뒤 distance로), 'spring' = 휠로 끄는 만큼 러버밴딩 (distance에서 min·maxDistance까지,
//   휠 한 칸 = 0.1, zoomHalf만큼 굴리면 그 폭의 절반), 휠을 멈추고 CAM_ZOOM_IDLE초가 지나면 스프링으로 바로 튕겨 distance로.
//   두 손가락(터치)도 같게: 손가락 사이가 처음의 e배로 좁아질 때마다 CAM_PINCH_K만큼 (벌리면 당겨진다), 손가락을 떼면 바로 튕겨 돌아간다.
// 지금 적용한 어긋남(ah·av·az)과의 차이만큼만 카메라를 돌리고 당긴다 (따라 돌기·이동은 그대로). 스프링: CAM_RB_W rad/s, 감쇠 CAM_RB_Z
const CAM_RB_W = 28, CAM_RB_Z = 0.5, CAM_ZOOM_IDLE = 0.15, CAM_PINCH_K = 0.5, TAU = Math.PI * 2;
const camTouches = new Map();   // 캔버스 위 손가락 (id → 자리)
let camPinch = null;   // 두 손가락 거리 조절 중: { d0: 처음 손가락 사이, z0: 그때 끈 양 }
const pinchD = () => { const [a, b] = [...camTouches.values()]; return Math.max(1, Math.hypot(a.x - b.x, a.y - b.y)); };
const zoomIn = (m, D) => camEl.zt < 0 ? rbIn(camEl.az, camEl.az > 0 ? m.maxDistance - m.distance : m.distance - m.minDistance, D) : camEl.zr;   // 지금 거리 어긋남 → 끈 양 (튕기는 중이면 그 자리에서 이어서)
const camEl = { on: false, id: null, px: 0, py: 0, rh: 0, rv: 0, ah: 0, av: 0, vh: 0, vv: 0, zr: 0, az: 0, vz: 0, zt: -1 };
function camElReset() { Object.assign(camEl, { on: false, rh: 0, rv: 0, ah: 0, av: 0, vh: 0, vv: 0, zr: 0, az: 0, vz: 0, zt: -1 }); camPinch = null; }
function dragAxis(v) { return v === true ? { m: 'free' } : typeof v === 'number' && v > 0 ? { m: 'rb', L: v * DEG } : { m: 'off' }; }   // (함수 선언: camLimits가 앞에서 부른다)
function camDragAxes() {   // 지금 모드의 { h: 가로, v: 세로 } (m = 'free'·'rb'·'off', L = 러버밴딩 한계 rad)
  const d = camPreCfg().drag;
  if (d === undefined || d === true) return { h: { m: 'free' }, v: { m: 'free' } };
  if (d && typeof d === 'object') return { h: dragAxis(d.x), v: dragAxis(d.y) };
  return { h: dragAxis(d), v: dragAxis(d) };   // 숫자 하나 (가로·세로 같게) 또는 false
}
const camDragHalf = () => Math.max(1e-3, camPreCfg().dragHalf ?? 0.35);
const rbOut = (r, L, D) => Math.sign(r) * L * Math.abs(r) / (Math.abs(r) + D);   // 끈 양 → 보이는 값 (L에 끝없이 가까워진다)
const rbIn = (a, L, D) => { if (!(L > 0)) return 0; const m = Math.min(Math.abs(a), L * 0.999); return Math.sign(a) * D * m / (L - m); };   // 보이는 값 → 끈 양 (튕기는 중에 다시 잡을 때)
const axIn = (A, a, D) => A.m === 'free' ? a / TAU : A.m === 'rb' ? rbIn(a, A.L, D) : 0;   // 지금 각도 → 끈 거리
const axOut = (A, r, D) => A.m === 'free' ? r * TAU : A.m === 'rb' ? rbOut(r, A.L, D) : 0;   // 끈 거리 → 각도 (자유는 OrbitControls와 같은 빠르기)
const camElUsed = (A) => !(A.h.m === 'free' && A.v.m === 'free') && !(A.h.m === 'off' && A.v.m === 'off');   // 직접 처리하는 경우 (둘 다 자유면 OrbitControls, 둘 다 꺼짐이면 없음)
const camCanTouch = () => titleK >= 1 && !clearSeq && !editMode && !winUp();
canvas.addEventListener('pointerdown', (e) => {
  if (e.pointerType === 'touch') camTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });
  const m = camPreCfg();
  if (camTouches.size >= 2) {   // 두 손가락: 끌기는 멈추고 (러버밴딩은 튕겨 돌아간다) 거리 조절로 ('spring'일 때만. 'auto'면 OrbitControls)
    camEl.on = false;
    if (m.zoom === 'spring' && camCanTouch() && !camPinch) {
      const D = Math.max(1e-3, m.zoomHalf ?? 0.35);
      camEl.zr = zoomIn(m, D); camEl.zt = 0; camEl.vz = 0;
      camPinch = { d0: pinchD(), z0: camEl.zr };
      camRet = null; camBackAt = 0;
    }
    return;
  }
  const A = camDragAxes();
  if (!camElUsed(A) || e.button !== 0 || !camCanTouch()) return;
  const D = camDragHalf();
  Object.assign(camEl, { on: true, id: e.pointerId, px: e.clientX, py: e.clientY, rh: axIn(A.h, camEl.ah, D), rv: axIn(A.v, camEl.av, D), vh: 0, vv: 0 });
  camRet = null; camBackAt = 0;   // 끄는 동안은 자동 카메라를 멈춘다 (돌아가던 중이면 그만)
});
addEventListener('pointermove', (e) => {
  if (camTouches.has(e.pointerId)) camTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (camPinch && camTouches.size >= 2) { camEl.zr = camPinch.z0 + Math.log(camPinch.d0 / pinchD()) * CAM_PINCH_K; camEl.zt = 0; return; }   // (벌리면 음수 = 당겨진다)
  if (!camEl.on || e.pointerId !== camEl.id) return;
  const k = 1 / innerHeight;   // 끈 거리는 화면 높이 단위 (해상도와 상관없게)
  camEl.rh -= (e.clientX - camEl.px) * k; camEl.rv += (e.clientY - camEl.py) * k; camEl.px = e.clientX; camEl.py = e.clientY;
});
for (const ev of ['pointerup', 'pointercancel']) addEventListener(ev, (e) => {
  camTouches.delete(e.pointerId);
  if (camPinch && camTouches.size < 2) { camPinch = null; camEl.zt = CAM_ZOOM_IDLE; if (autoCam) camBackAt = performance.now() + CAM_BACK_WAIT; }   // 손가락을 떼면 바로 튕겨 돌아간다
  if (!camEl.on || e.pointerId !== camEl.id) return;
  camEl.on = false;
  if (autoCam) camBackAt = performance.now() + CAM_BACK_WAIT;   // 손을 뗀 뒤부터 자동 카메라 (자유 방향을 되돌린다)
});
// 휠 (zoom 'spring'일 때만. 'auto'면 OrbitControls)
canvas.addEventListener('wheel', (e) => {
  const m = camPreCfg();
  if (m.zoom !== 'spring' || titleK < 1 || clearSeq || editMode) return;
  e.preventDefault();
  const D = Math.max(1e-3, m.zoomHalf ?? 0.35), dy = e.deltaY * (e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? 400 : 1);
  camEl.zr = zoomIn(m, D) + dy / 1000; camEl.zt = 0; camEl.vz = 0;   // (휠 한 칸 = 100 → 0.1)
  camRet = null; if (autoCam) camBackAt = performance.now() + CAM_BACK_WAIT;
}, { passive: false });
const springStep = (x, v, h) => { v += (-CAM_RB_W * CAM_RB_W * x - 2 * CAM_RB_Z * CAM_RB_W * v) * h; return [x + v * h, v]; };
function camElastic(dt) {
  const A = camDragAxes(), m = camPreCfg(), D = camDragHalf();
  if (!camElUsed(A) && m.zoom !== 'spring') { if (camEl.ah || camEl.av || camEl.az || camEl.on) camElReset(); return; }
  let th = camEl.ah, tv = camEl.av, tz = camEl.az;
  const h = Math.min(dt, 0.05) / 4;   // 스프링은 작은 단계 4번 (프레임이 길어도 튀지 않게)
  if (camEl.on) { th = axOut(A.h, camEl.rh, D); tv = axOut(A.v, camEl.rv, D); }
  else {
    // 러버밴딩 방향: 스프링으로 제자리. 꺼진 방향: 0
    if (A.h.m === 'rb') for (let i = 0; i < 4; i++) [th, camEl.vh] = springStep(th, camEl.vh, h); else if (A.h.m === 'off') th = 0;
    if (A.v.m === 'rb') for (let i = 0; i < 4; i++) [tv, camEl.vv] = springStep(tv, camEl.vv, h); else if (A.v.m === 'off') tv = 0;
    // (자유 방향은 그대로 둔다: 자동 카메라면 camBack이 제자리로 옮기고 camRetBegin이 어긋남을 잊는다)
    if (Math.abs(th) < 1e-5 && Math.abs(camEl.vh) < 1e-3) { th = 0; camEl.vh = 0; }
    if (Math.abs(tv) < 1e-5 && Math.abs(camEl.vv) < 1e-3) { tv = 0; camEl.vv = 0; }
  }
  if (m.zoom === 'spring') {   // 휠 거리: 굴리는 동안 러버밴딩, 멈추면 스프링으로 distance로
    const Dz = Math.max(1e-3, m.zoomHalf ?? 0.35);
    if (camPinch) camEl.zt = 0;   // (두 손가락을 대고 있는 동안은 멈춰 있어도 그대로)
    if (camEl.zt >= 0 && (camEl.zt += dt) < CAM_ZOOM_IDLE) tz = rbOut(camEl.zr, camEl.zr > 0 ? Math.max(0, m.maxDistance - m.distance) : Math.max(0, m.distance - m.minDistance), Dz);
    else { camEl.zt = -1; for (let i = 0; i < 4; i++) [tz, camEl.vz] = springStep(tz, camEl.vz, h); if (Math.abs(tz) < 1e-4 && Math.abs(camEl.vz) < 1e-3) { tz = 0; camEl.vz = 0; } }
  } else tz = 0;
  const dh = th - camEl.ah, dv = tv - camEl.av, dz = tz - camEl.az;
  camEl.ah = th; camEl.av = tv; camEl.az = tz;
  if (!dh && !dv && !dz) return;
  _tmp.copy(camera.position).sub(controls.target);
  if (dh) _tmp.applyAxisAngle(UP, dh);
  if (dv) {
    const r = _tmp.length(), hz = Math.hypot(_tmp.x, _tmp.z) || 1e-6, p = Math.max(-0.2, Math.min(1.5, Math.atan2(_tmp.y, hz) + dv)), s = r * Math.cos(p) / hz;
    _tmp.x *= s; _tmp.z *= s; _tmp.y = r * Math.sin(p);
  }
  if (dz) _tmp.setLength(Math.max(0.5, _tmp.length() + dz));
  camera.position.copy(controls.target).add(_tmp);
}
// AO 한 줄: 켜기/끄기, 세기, 흰색 보기
let aoOn = true;
const aoK = $el('aoK'), aoKv = $el('aoKv');
const applyAO = () => { U.uAO.value = aoOn ? +aoK.value : 0; aoKv.textContent = (+aoK.value).toFixed(1); };
$el('aoBtn').onclick = (e) => { aoOn = !aoOn; e.target.textContent = aoOn ? '켜짐' : '꺼짐'; applyAO(); e.target.blur(); };
aoK.oninput = applyAO; aoK.onchange = (e) => e.target.blur();
$el('aoWhite').onclick = (e) => { U.uWhite.value = 1 - U.uWhite.value; e.target.textContent = U.uWhite.value ? '색 보기' : '흰색 보기'; e.target.blur(); };
$el('moonI').oninput = (e) => { ENV_PLAY.moon = +e.target.value; applyEnv(); $el('moonIV').textContent = (+e.target.value).toFixed(2); };
$el('moonC').oninput = (e) => { ENV_PLAY.moonC.set(e.target.value); applyEnv(); };
for (const id of ['moonI', 'moonC']) $el(id).onchange = (e) => e.target.blur();
setInput('aoK', CFG.map.ao);
// 맵 셋팅 바꾸기: 설정 메뉴 슬라이더·하늘빛·날씨를 그 셋팅 값으로 (슬라이더는 그 뒤에 따로 만져 볼 수 있다)
function applyMapPreset(i) {
  mapIdx = (i + MAP_PRESETS.length) % MAP_PRESETS.length;
  const p = MAP_PRESETS[mapIdx];
  for (const [id, v] of [['wind', p.wind], ['windDir', p.windDir], ['debris', p.debris], ['fog', p.fog], ['fogC', p.fogColor], ['moonI', p.moon], ['moonC', p.moonColor]]) setInput(id, v);
  ENV_PLAY.sky = p.sky; ENV_PLAY.skyC.set(p.skyColor); ENV_PLAY.gndC.set(p.groundColor); ENV_PLAY.bgAuto = !p.bgColor; bgOf(p, ENV_PLAY.bg); applyEnv();
  setWeather(p);
  for (const [id, v] of [['rainA', p.rain], ['sandA', p.sand], ['boltA', p.lightning]]) setInput(id, v);
  $el('sandC').value = p.sandColor ?? '#c8a070';
  $el('mapBtn').textContent = `맵 셋팅: ${p.name} (${mapIdx + 1}/${MAP_PRESETS.length})`;
}
// 남은 적이 map.stormAt대 이하가 되면 map.stormPreset 셋팅으로 stormTime초에 걸쳐 바뀐다 (클리어가 가깝다는 신호, 분위기 전환). 한 판에 한 번
let storm = null, stormDone = false;
const _sc1 = new THREE.Color(), _sc2 = new THREE.Color();
const mixHex = (a, b, e) => '#' + _sc1.set(a ?? '#000000').lerp(_sc2.set(b ?? '#000000'), e).getHexString();
function stormTick(dt) {
  if (!storm) {
    if (stormDone || titleState !== 'play' || editMode || !(CFG.map.stormAt > 0) || enemyLeft() > CFG.map.stormAt) return;
    stormDone = true;
    const bi = MAP_PRESETS.findIndex((p) => p.name === CFG.map.stormPreset);
    if (bi < 0 || bi === mapIdx) return;
    storm = { a: MAP_PRESETS[mapIdx], b: MAP_PRESETS[bi], bi, t: 0 };
  }
  storm.t += dt;
  const k = Math.min(1, storm.t / Math.max(0.01, CFG.map.stormTime ?? 6)), e = k * k * (3 - 2 * k), A = storm.a, B = storm.b;
  if (k >= 1) { applyMapPreset(storm.bi); storm = null; return; }   // 끝: 셋팅 그대로 (설정 메뉴 슬라이더까지)
  const L = (n) => lerp(A[n] ?? 0, B[n] ?? 0, e);
  let wd = (B.windDir ?? 0) - (A.windDir ?? 0); wd = ((wd % 360) + 540) % 360 - 180;   // 바람 방향은 가까운 쪽으로 돈다
  for (const [id, v] of [['wind', L('wind')], ['windDir', Math.round((A.windDir ?? 0) + wd * e)], ['debris', L('debris')], ['fog', L('fog')], ['fogC', mixHex(A.fogColor, B.fogColor, e)],
    ['moonI', L('moon')], ['moonC', mixHex(A.moonColor, B.moonColor, e)]]) setInput(id, v);
  ENV_PLAY.sky = L('sky'); ENV_PLAY.skyC.set(mixHex(A.skyColor, B.skyColor, e)); ENV_PLAY.gndC.set(mixHex(A.groundColor, B.groundColor, e));
  ENV_PLAY.bgAuto = false; bgOf(A, ENV_PLAY.bg).lerp(bgOf(B, _sc1), e); applyEnv();   // 하늘색도 두 셋팅 사이로
  WEATHER.rain = L('rain'); WEATHER.sand = L('sand'); WEATHER.lightning = L('lightning');
  rainFx.u.uColor.value.set(mixHex(A.rainColor ?? '#a8b8d0', B.rainColor ?? '#a8b8d0', e)).multiplyScalar(CFG.map.rainBright ?? 0.7);
  WEATHER.sandCol.set(mixHex(A.sandColor ?? '#c8a070', B.sandColor ?? '#c8a070', e));
}
// 날씨 양 슬라이더 (비 · 모래바람 · 번개)
for (const [id, key] of [['rainA', 'rain'], ['sandA', 'sand'], ['boltA', 'lightning']]) {
  const el = $el(id);
  el.oninput = (e) => { WEATHER[key] = +e.target.value; $el(id + 'V').textContent = (+e.target.value).toFixed(2); };
  el.onchange = (e) => e.target.blur();
}
$el('sandC').oninput = (e) => WEATHER.sandCol.set(e.target.value);   // 모래 색 (설정 메뉴에서 바로)
$el('sandC').onchange = (e) => e.target.blur();
$el('mapBtn').onclick = (e) => { applyMapPreset(mapIdx + 1); e.target.blur(); };   // 처음 셋팅은 90_loop.js에서 (뒤 파일의 값이 다 준비된 뒤)
resetGrowth();
resize();
Object.assign(DBG, { U, ballHit, cliffG, mainRoadX, addScorchDecal, resetCamera, renderer, scene, rt, tank, keys, fireCannon, physStep, updateBalls, fieldTick, burning, fFire, fChar, fGrow, footprints, spawnTank, resetTank, heightAt, PHYS_H, driveEffects, syncTankVisual, smokeP, glowP, targets, destroyTarget, BRIDGE, waterAt, creekPoly, explode, trackRT, balls, ballGeo, ballMat, crates, wireSpans, allPoles, WRECKS, PUDDLES, poleTilt, kickPole, toggleCollisionView, CREEK_UP: () => CREEK_UP, creekPoly, aoMs: () => aoMs, aoHits: () => aoHits, gapData });

// 카메라는 탱크 뒤에서 시작해 탱크를 따라 이동. 마우스로 자유롭게 돌릴 수 있다.
// 화면 가운데에는 탱크가 아니라 탱크가 바라보는 쪽 9m 앞을 둔다: 기본 시점에서 탱크는 화면 세로 2/3쯤 아래에 보이고
// 앞이 넓게 보인다. 바라보는 쪽 = 포탑이 겨눈 방향(기본) 또는 차체 앞 (HUD 토글). 탱크·포탑이 돌면 부드럽게 따라 돈다
const CC = CFG.camera;   // 모드와 상관없는 값 (seeThrough·minHeight). 모드 값은 CAMV
const camLead = new THREE.Vector3(), _cf = new THREE.Vector3(), _cl2 = new THREE.Vector3();
// 보는 방향 기준: 'auto' 자동(키보드 = 포탑, 게임패드 = 차체) · 'hull' 차체 방향 · 'turret' 포탑 방향. 고른 것은 localStorage에 기억
const CAM_MODES = ['auto', 'hull', 'turret'], CAM_MODE_KO = { auto: '자동', hull: '차체 방향', turret: '포탑 방향' };
let camMode = 'auto';
try { const m = localStorage.getItem('MightyMolly.camMode'); if (CAM_MODES.includes(m)) camMode = m; } catch (_) {}
const camTurret = () => { if (camMode !== 'auto') return camMode === 'turret'; try { return !inputPad; } catch (_) { return true; } };
function setCamMode(m) {
  camMode = m; try { localStorage.setItem('MightyMolly.camMode', m); } catch (_) {}
  $el('camModeBtn').textContent = `시점: ${CAM_MODE_KO[m]}`;
}
setCamMode(camMode);
// 소리 크기 (0~1): 일시정지 창 '설정' 탭과 설정 메뉴 게이지가 같이 쓴다. 기억해 둔다
let volNow = 0.5;
try { const v = parseFloat(localStorage.getItem('MightyMolly.volume')); if (v >= 0 && v <= 1) volNow = v; } catch (_) {}
function setVolume(v) {
  volNow = Math.max(0, Math.min(1, Math.round(v * 100) / 100));
  try { sfx.setVolume(volNow); } catch (_) {}   // (로딩 중엔 소리가 아직 없다: 60_audio.js 뒤에서 다시 맞춘다)
  try { localStorage.setItem('MightyMolly.volume', String(volNow)); } catch (_) {}
  const el = $el('vol'); el.value = volNow; $el('volV').textContent = volNow.toFixed(2);
}
setVolume(volNow);
// 켜기/끄기 설정 (일시정지 창 '설정' 탭): 기억해 두었다가 다시 쓴다
const saveOpt = (k, v) => { try { localStorage.setItem('MightyMolly.' + k, v ? '1' : '0'); } catch (_) {} };
let autoCam = loadOpt('autoCam', true), shakeOn = true,   // (화면 흔들림은 늘 켬: 설정 탭에서 뺐다)
    rumbleOn = loadOpt('rumble', true);
const setAutoCam = (v) => { autoCam = v; saveOpt('autoCam', v); if (!v) { camBackAt = 0; camRet = null; } };
const _dofT = new THREE.Vector3();
const setRumbleOn = (v) => { rumbleOn = v; saveOpt('rumble', v); if (v) padRumbleNow(0.5, 0.7, 160); };   // 켜면 한 번 울려서 되는지 알 수 있게
// 화면 밝기 (0.5~1.5, 1 = 그대로): 후처리에서 감마로 (어두운 곳이 밝아진다)
let brightness = 1;
try { const b = parseFloat(localStorage.getItem('MightyMolly.bright')); if (b >= 0.5 && b <= 1.5) brightness = b; } catch (_) {}
// 설정 탭 모두 초기 값으로 (일시정지 → 설정 → [R], 확인 창에서 예)
function resetSettings() {
  setVolume(0.5); setCamMode('auto'); setAutoCam(true); setRumbleOn(true); setBright(1); setCamPreset(CAMP_START);
  if (crtOn !== !!CRT.enabled) setCrt(!!CRT.enabled);
}
function setBright(b) { brightness = Math.max(0.5, Math.min(1.5, Math.round(b * 20) / 20)); postMat.uniforms.uBright.value = brightness; try { localStorage.setItem('MightyMolly.bright', String(brightness)); } catch (_) {} }
const camFocus = (out) => { out.copy(tank.pos).add(camLead); out.y += CAMV.height; return out; };   // 화면 가운데 (카메라 모드 height만큼 위로)
function updateCamLead(dt, snap = false) {
  const ty = camTurret() ? tank.tyaw || 0 : 0;
  _cl2.set(Math.sin(ty), 0, Math.cos(ty)).applyQuaternion(tank.q); _cl2.y = 0;
  if (_cl2.lengthSq() < 1e-4) return;
  _cl2.normalize().multiplyScalar(CAMV.lead);
  if (snap) camLead.copy(_cl2); else camLead.lerp(_cl2, Math.min(1, dt * 2.5));
}
const lastFollow = tank.pos.clone();
// 카메라는 탱크가 도는 방향을 레이싱 게임처럼 한 박자 늦게 느슨하게 따라 돈다
const tankYaw = () => { _fwd.set(0, 0, 1).applyQuaternion(tank.q); return Math.atan2(_fwd.x, _fwd.z) + (camTurret() ? tank.tyaw || 0 : 0); };   // 카메라가 따라 도는 방향
let camYaw = 0;
// 기본 위치: 화면 가운데에서 42.6m, 내려다보는 각 33.6도, 탱크 뒤에서 오른쪽으로 20도 돌아가 탱크 오른쪽 옆면이 살짝 보인다 (설정. 카메라 초기화 버튼도 이것)
function resetCamera() {
  camYaw = tankYaw() + CAMV.yaw * DEG;
  updateCamLead(0, true);
  camFocus(controls.target);
  const hd = CAMV.distance * Math.cos(CAMV.pitch * DEG);
  camera.position.copy(controls.target).add(_tmp.set(-Math.sin(camYaw) * hd, CAMV.distance * Math.sin(CAMV.pitch * DEG), -Math.cos(camYaw) * hd));
  lastFollow.copy(controls.target);
  controls.update();
}
resetCamera();
DBG.lastFollow = lastFollow;
// 카메라가 땅 속으로 들어가지 않게: 카메라 자리와 화면 가운데 쪽으로 조금 나아간 두 곳의 땅 높이 + minHeight 아래로는 못 내려간다
// (가까운 면이 화면 앞을 가로막지 않게 앞쪽도 본다). 마우스로 낮게 돌려도 여기서 막힌다
const CAM_MIN_H = CC.minHeight ?? 2;
function camAboveGround() {
  const p = camera.position, t = controls.target;
  let dx = t.x - p.x, dz = t.z - p.z;
  const d = Math.hypot(dx, dz) || 1; dx /= d; dz /= d;
  const g = Math.max(heightAt(p.x, p.z), heightAt(p.x + dx * 2, p.z + dz * 2), heightAt(p.x + dx * 4, p.z + dz * 4)) + CAM_MIN_H;
  if (p.y < g) p.y = g;
}
// 전환이 끝났을 때의 플레이 카메라 자리: 포탑이 정면(전환 동안 가운데로 돌아온다)일 때의 기본 자리
function playRestCam() {
  const ty = tank.tyaw; tank.tyaw = 0;
  resetCamera();
  tank.tyaw = ty;
}
function followYaw(dt) {
  let d = tankYaw() + CAMV.yaw * DEG - camYaw;
  d = Math.atan2(Math.sin(d), Math.cos(d));
  const step = d * Math.min(1, dt * CAMV.follow);
  camYaw += step;
  _tmp.copy(camera.position).sub(controls.target).applyAxisAngle(UP, step);
  camera.position.copy(controls.target).add(_tmp);
}
// 설정 메뉴 '카메라': 지금 화면(타이틀·플레이·임무 완료)의 카메라·아웃포커싱 값을 바로 바꿔 본다 (config에는 저장하지 않음).
// 화면마다 따로: 타이틀 = config title.camera, 플레이 = camera, 임무 완료 = clear.camera (매 프레임 읽으니 바로 보인다). 그 화면에 없는 값은 게이지를 끈다.
// [이름, 최소, 최대, 단계, 값 글자, 읽기(화면) → 값 또는 undefined(없음), 쓰기(화면, 값)]
const camScr = () => clearSeq ? 'clear' : titleK < 1 ? 'title' : 'play';
const CAM_SCR_KO = { title: '타이틀', play: '플레이', clear: '임무 완료' };
const titleCamCfg = () => TT.camera || (TT.camera = {});
const camCfg = (m) => m === 'title' ? titleCamCfg() : m === 'clear' ? CLR_CAM : camPreCfg();   // (플레이 = 지금 카메라 모드)
const CAM_DEF = { title: { fov: 30, distance: 16, pitch: 8, yaw: 65 } };   // 타이틀 카메라에서 config에 없을 때 (50_title.js와 같은 값)
const camGet = (k) => (m) => { const c = camCfg(m); return c[k] ?? CAM_DEF[m]?.[k]; };
const camReCam = () => { if (camScr() === 'play') { camValues(); resetCamera(); } };   // 플레이: 거리·각도는 기본 자리로 바로 옮겨 보여 준다
const playOnly = (get) => (m) => m === 'play' ? get() : undefined;
const CAM_ROWS = [
  ['시야각', 10, 90, 1, (v) => `${v}°`, camGet('fov'), (m, v) => { camCfg(m).fov = v; }],
  ['거리', 5, 400, 0.5, (v) => `${v.toFixed(1)}m`, camGet('distance'), (m, v) => { camCfg(m).distance = v; if (m === 'play') { camLimits(); camReCam(); } }],
  ['내려다봄', -10, 85, 0.5, (v) => `${v.toFixed(1)}°`, camGet('pitch'), (m, v) => { camCfg(m).pitch = v; if (m === 'play') camReCam(); }],
  ['방향', -180, 180, 1, (v) => `${v}°`, camGet('yaw'), (m, v) => { camCfg(m).yaw = v; if (m === 'play') camReCam(); }],
  ['높이', -5, 10, 0.1, (v) => `${v.toFixed(1)}m`, (m) => camCfg(m).height ?? (m === 'title' ? 2 : 1.4), (m, v) => { camCfg(m).height = v; }],   // 화면 가운데를 탱크보다 이만큼 위로
  ['앞으로', 0, 30, 0.5, (v) => `${v.toFixed(1)}m`, playOnly(() => camPreCfg().lead), (m, v) => { camPreCfg().lead = v; }],
  ['따라 돎', 0, 10, 0.1, (v) => v.toFixed(1), playOnly(() => camPreCfg().follow), (m, v) => { camPreCfg().follow = v; }],
  ['안개 배율', 0.05, 2, 0.05, (v) => v.toFixed(2), playOnly(() => camPreCfg().fog), (m, v) => { camPreCfg().fog = v; }],
  ['주광 배율', 0, 3, 0.05, (v) => v.toFixed(2), playOnly(() => camPreCfg().moon), (m, v) => { camPreCfg().moon = v; }],
  ['DOF 세기', 0, 1, 0.05, (v) => v.toFixed(2), (m) => camCfg(m).dof.strength, (m, v) => { camCfg(m).dof.strength = v; }],   // 화면마다의 카메라 dof
  ['DOF range', 0, 40, 0.5, (v) => `${v.toFixed(1)}m`, (m) => camCfg(m).dof.range, (m, v) => { camCfg(m).dof.range = v; }],
  ['DOF fall', 1, 100, 1, (v) => `${v}m`, (m) => camCfg(m).dof.fall, (m, v) => { camCfg(m).dof.fall = v; }],
  ['DOF px', 0, 8, 0.1, (v) => v.toFixed(1), (m) => camCfg(m).dof.px, (m, v) => { camCfg(m).dof.px = v; }],
];
const camSl = [];   // { it, el, val, row }
let camSlScr = null, camSlKey = '', camSlInit = null;   // 게이지가 지금 보여 주는 화면, 처음 값 (화면마다. 처음 맞출 때 한 번 읽는다: CLR_CAM은 뒤 파일)
for (const row of CAM_ROWS) {
  const [name, min, max, step, fmt, , set] = row;
  const it = document.createElement('span'), lab = document.createElement('span'), el = document.createElement('input'), val = document.createElement('b'), vs = document.createElement('span');
  lab.textContent = name; el.type = 'range'; el.min = min; el.max = max; el.step = step;
  el.oninput = () => { if (camSlScr) { set(camSlScr, +el.value); val.textContent = fmt(+el.value); } };
  el.onchange = () => el.blur();
  vs.append(val); it.append(lab, el, vs); $el('camSl').append(it);
  camSl.push({ it, el, val, row });
}
// 게이지를 지금 화면 값으로 (메뉴가 열려 있을 때 0.25초마다 보고, 화면이 바뀌었으면). 그 화면에 없는 값은 끈다
function camSlSync(force) {
  if (!camSlInit) { camSlInit = {}; for (const m of ['title', 'play', 'clear']) camSlInit[m] = CAM_ROWS.map((r) => r[5](m)); }
  const m = camScr(), key = m + '/' + camPre;
  if (key === camSlKey && !force) return;
  camSlScr = m; camSlKey = key;
  $el('camScr').textContent = `(${CAM_SCR_KO[m]} · ${camPreCfg().name})`;
  for (const { it, el, val, row } of camSl) {
    const v = row[5](m), off = v === undefined;
    el.disabled = off; it.classList.toggle('off', off);
    if (!off) el.value = v;
    val.textContent = off ? '-' : row[4](+el.value);
  }
}
// 초기화: 타이틀·임무 완료 카메라와 모든 카메라 모드를 처음 값으로 되돌린다
$el('camSlReset').onclick = (e) => {
  camSlSync();
  for (const m of ['title', 'clear']) CAM_ROWS.forEach((r, i) => { if (camSlInit[m][i] !== undefined) r[6](m, camSlInit[m][i]); });
  JSON.parse(CAMP_CFG0).forEach((o, i) => Object.assign(CFG.camera[CAMP_KEYS[i]], o));
  camLimits(); camReCam();
  camSlSync(true);
  e.target.blur();
};
setInterval(() => { if (hudEl.style.display === 'block') camSlSync(); }, 250);
// 설정 메뉴 크기: 우하단 핸들(#hudGrip)을 끌어 바꾼다 (기억해 둔다). 게이지 묶음은 메뉴 폭이 좁으면 1단
{
  const hud = $el('hud'), grip = $el('hudGrip'), groups = hud.querySelectorAll('.wg');
  try { const z = JSON.parse(localStorage.getItem('MightyMolly.dbgSize')); if (z && z.w > 100 && z.h > 100) { hud.style.width = z.w + 'px'; hud.style.height = z.h + 'px'; hud.style.boxSizing = 'border-box'; } } catch (_) {}
  const place = () => {
    const r = hud.getBoundingClientRect(), on = r.width > 0;
    grip.style.display = on ? 'block' : 'none';
    if (!on) return;
    grip.style.left = (r.right - 8) + 'px'; grip.style.top = (r.bottom - 8) + 'px';   // (귀퉁이에 반쯤 걸쳐: 스크롤바와 겹치지 않게)
    const one = hud.clientWidth < 620;   // 2단(이름·게이지·값 × 2)이 들어가지 않는 폭
    for (const g of groups) g.classList.toggle('one', one);
  };
  new ResizeObserver(place).observe(hud);
  addEventListener('resize', place);
  let drag = null;
  grip.addEventListener('pointerdown', (e) => {
    const r = hud.getBoundingClientRect();
    drag = { x: e.clientX, y: e.clientY, w: r.width, h: r.height }; grip.setPointerCapture(e.pointerId); e.preventDefault();
  });
  grip.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const w = Math.max(240, Math.min(innerWidth - 20, drag.w + e.clientX - drag.x)), h = Math.max(160, Math.min(innerHeight - 20, drag.h + e.clientY - drag.y));
    hud.style.maxWidth = hud.style.maxHeight = 'none';
    hud.style.width = w + 'px'; hud.style.height = h + 'px'; hud.style.boxSizing = 'border-box';
  });
  const end = () => {
    if (!drag) return; drag = null;
    try { localStorage.setItem('MightyMolly.dbgSize', JSON.stringify({ w: hud.offsetWidth, h: hud.offsetHeight })); } catch (_) {}
  };
  grip.addEventListener('pointerup', end); grip.addEventListener('pointercancel', end);
}

